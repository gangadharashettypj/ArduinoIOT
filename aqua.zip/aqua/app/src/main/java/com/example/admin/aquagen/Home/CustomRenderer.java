package com.example.admin.aquagen.Home;

import android.graphics.Canvas;
import android.graphics.PointF;
import android.text.TextPaint;

import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.renderer.XAxisRenderer;
import com.github.mikephil.charting.utils.FSize;
import com.github.mikephil.charting.utils.Transformer;
import com.github.mikephil.charting.utils.Utils;
import com.github.mikephil.charting.utils.ViewPortHandler;

class CustomRenderer extends XAxisRenderer {
    public CustomRenderer(ViewPortHandler viewPortHandler, XAxis xAxis, Transformer transformer) {
        super(viewPortHandler, xAxis, transformer);
    }

    @Override
    protected void drawLabel(Canvas c, String label, int xIndex, float x, float y, PointF anchor, float angleDegrees) {
        super.drawLabel(c, label, xIndex, x, y, anchor, angleDegrees);
        String lines[] = label.split("\n");
        TextPaint mAxisLabelTextPaint= new TextPaint();
        mAxisLabelTextPaint.set(mAxisLabelPaint);
        for (int i = 0; i < lines.length; i++) {
            float vOffset = i * mAxisLabelTextPaint.getTextSize();
            Utils.drawMultilineText(c, lines[i], x, y + vOffset, mAxisLabelTextPaint,new FSize(10,10), anchor, angleDegrees);
        }
    }
}
