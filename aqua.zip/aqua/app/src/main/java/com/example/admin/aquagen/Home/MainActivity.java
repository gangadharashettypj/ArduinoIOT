package com.example.admin.aquagen.Home;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PointF;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Html;
import android.text.TextPaint;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.CreatePlatformEndpointRequest;
import com.amazonaws.services.sns.model.CreatePlatformEndpointResult;
import com.amazonaws.services.sns.model.CreateTopicRequest;
import com.amazonaws.services.sns.model.CreateTopicResult;
import com.amazonaws.services.sns.model.SubscribeResult;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.admin.aquagen.Authentication.LoginActivity;
import com.example.admin.aquagen.Info.AboutUs;
import com.example.admin.aquagen.Level.levelActivity;
import com.example.admin.aquagen.MilkActivity;
import com.example.admin.aquagen.Notifications.NotificationList;
import com.example.admin.aquagen.R;
import com.example.admin.aquagen.Shift.ShiftActivity;
import com.example.admin.aquagen.SplashScreenActivity;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.google.firebase.iid.FirebaseInstanceId;
import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParserException;

import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import lecho.lib.hellocharts.model.PointValue;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private ProgressDialog pd;
    private TextView tvToday, tvYesterday, tvRefreshTime;
    private BarChart barChartWeely;
    public static CountDownTimer tokenThread;
    public static TextView tvDuration;
    private List<String> unitsList;
    private HashMap<String, HashMap<String,String>> unitMap;
    private Spinner unitSpinner;
    private SwipeRefreshLayout srl;
    private DrawerLayout drawer;
    private LinearLayout noInternet, internet;
    private Button retryInternet;
    private SharedPreferences mShared;

    private NavigationView navigationView;
    private String JSON_URL = "http://54.71.150.252/aquagen/v1/auth/login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mShared = this.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);
        noInternet = findViewById(R.id.noInternetMainLayout);
        internet = findViewById(R.id.internetMainLayout);
        retryInternet = findViewById(R.id.btRetryMain);
        //getActionBar().setDisplayHomeAsUpEnabled(true);

        //== initializing the last updated time ==
        tvRefreshTime = findViewById(R.id.tvCurrent_Time);

        retryInternet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {

                    internet.setVisibility(View.VISIBLE);
                    noInternet.setVisibility(View.GONE);
                    tvRefreshTime.setVisibility(View.VISIBLE);
                } else {

                    internet.setVisibility(View.GONE);
                    noInternet.setVisibility(View.VISIBLE);
                    tvRefreshTime.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(),"No internet found....\nPlease switch on the internet and then retry",Toast.LENGTH_LONG).show();
                    return;
                }

            }
        });

        if(!mShared.getBoolean("flag",false))
        {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
        }
        else {

//            Log.i("notidata",mShared.getString("Noti1","no data"));

            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            //== initializing spinner of the activity==
            unitSpinner = findViewById(R.id.sp_main);

            //== initialing the variables ==
            //== unitmap is used to store the device name , device id, consumption for all the devices in offline so that no need of calling the api again and again when user selectes differemt devices in the spinner==
            //== but unitmap stores only the todays value==
            //== unit list stores the set of keys inside the units array in the json response of the api which will be needed when we are parsing the json response in for loop ==
            //== here we get all he keys at a time. Below you can see the logic in the api calls ==
            unitMap = new HashMap<>();
            unitsList = new ArrayList<>();


            //======initializing notifications=======
            //====in order to create and subscribe notification topics in aws we need to run the code in seperate thread so this main code is in seperate thread===
            //====we are require two credentials from aws i.e. accesskey and secretkay which is to be given as a parameters for the BasicAWSCredentials() function==
            //===at present i am using the credentials of the user account of srivani akka=====
            //==in this thread we are using endpoint arn  arn:aws:sns:us-west-2:685446373664:MY_TOPIC_NAME replace the topic name with the actuaal topic name==
            //==here industry id is acting as the topic name i.e. for example ITJ1 or ELC1 where all the characters all in caps==
            //== i am creating topic also, if topic is there it will create an exception which will be catched in the catch block(its not an error)==
            new Thread(new Runnable(){
                public void run() {
                    try {

                        BasicAWSCredentials credentials = new BasicAWSCredentials("AKIAJVZ3GEMCA6FOZIBA", "iLHUghd95toLaYyOOVrCFCtxcTWxVO8LUEN13OCW");

//                        Log.i("token", FirebaseInstanceId.getInstance().getToken());

                        //create a new SNS client and set endpoint
                        AmazonSNSClient snsClient = new AmazonSNSClient(credentials);
                        snsClient.setRegion(Region.getRegion(Regions.US_WEST_2));

//                        Log.i("endpoint",        snsClient.getEndpoint());

                        CreateTopicRequest ctr = new CreateTopicRequest(mShared.getString("industryid",""));

                        CreateTopicResult ctres = snsClient.createTopic(ctr);
//                        Log.i("topic",ctres.getTopicArn());

                        CreatePlatformEndpointRequest cper = new CreatePlatformEndpointRequest()
                                .withPlatformApplicationArn("arn:aws:sns:us-west-2:685446373664:app/GCM/Aquagen")
                                .withCustomUserData("bh")
                                .withToken(FirebaseInstanceId.getInstance().getToken());

                        CreatePlatformEndpointResult cpeRes = snsClient
                                .createPlatformEndpoint(cper);

                        String endpointArn = cpeRes.getEndpointArn();
//                        Log.i("endpointArn",endpointArn);

                        SubscribeResult sr = snsClient.subscribe("arn:aws:sns:us-west-2:685446373664:"+mShared.getString("industryid",""),"application",endpointArn);
//                        Log.i("sr1",sr.getSubscriptionArn());
                        mShared.edit().putString("subscriptionArn",sr.getSubscriptionArn()).apply();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();


            //=========initializing the ui elements=============

            tvToday = findViewById(R.id.tvToday);
            tvYesterday = findViewById(R.id.tvYesterday);


            //==============Setting progress dialog properties====================
            pd = new ProgressDialog(MainActivity.this);
            pd.setTitle("Loading!");
            pd.setMessage("Please wait...");
            pd.setCanceledOnTouchOutside(false);
            pd.setCancelable(false);


            //== initalizing daily and weekly and monthly selection text view in the toolbar==
            tvDuration = toolbar.findViewById(R.id.tv_type);



            //== seeing the action for log out button in the navigation drawer ==
            //== naming convention is same as mentioned in the above comment ==
            findViewById(R.id.logout_navigation_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //== checking for internet connection ==
                    ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                    if (activeNetwork != null && activeNetwork.isConnected()) {


                    } else {

                        internet.setVisibility(View.GONE);
                        noInternet.setVisibility(View.VISIBLE);
                        tvRefreshTime.setVisibility(View.GONE);
                        //Toast.makeText(getApplicationContext(),"No internet connection...\nPlease connect to internet",Toast.LENGTH_LONG).show();
                        return;

                    }

                    //== clearing all the notificatins of older account ==
//                    for(int i=0; i <mShared.getInt("notiCount"+ mShared.getString("industryid",""),0); i++) {
//                        mShared.edit().remove("Noti"+ mShared.getString("industryid","")+String.valueOf(i+1)).apply();
//                    }
//                    mShared.edit().remove("notiCount"+ mShared.getString("industryid","")).apply();


                    //== getting user name and password==
                    mShared.edit().putString("username", "").apply();
                    mShared.edit().putString("password", "").apply();

                    //== setting the flag as false bec we are generating token automatically when it becomes invalid ==
                    //== when ever user signouts plase take care aboiut this flag in all sides which is in all the activities ==
                    mShared.edit().putBoolean("flag", false).apply();

                    //== when user signouts we need to remove its subscription from the topic he subscribed, otherwise he may get the notification for older industry after signing with other industry also ==
                    //== all the code related to aws sns notification we need to write in seperate threads==
                    //== and some points are same as i mentioned above ==
                    new Thread(new Runnable(){
                        public void run() {
                            try {


                                BasicAWSCredentials credentials = new BasicAWSCredentials("AKIAJVZ3GEMCA6FOZIBA", "iLHUghd95toLaYyOOVrCFCtxcTWxVO8LUEN13OCW");

                                Log.i("token", FirebaseInstanceId.getInstance().getToken());

                                //create a new SNS client and set endpoint
                                AmazonSNSClient snsClient = new AmazonSNSClient(credentials);
                                snsClient.setRegion(Region.getRegion(Regions.US_WEST_2));

                                Log.i("endpoint unsub",        snsClient.getEndpoint());


                                //== function call for unsubscribing==
//                                snsClient.unsubscribe(mShared.getString("subscriptionArn",""));


                                //==this is not required , this will delete the entire aquagen application from the web ==
                                //== so i commented (dont use)
//                                DeletePlatformApplicationRequest dpar = new DeletePlatformApplicationRequest()
//                                        .withPlatformApplicationArn("arn:aws:sns:us-west-2:685446373664:app/GCM/Aquagen");
//
//                                snsClient.deletePlatformApplication(dpar);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }).start();

                    //== after signout we are going to loginactivity again==
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                }
            });

            drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();

            navigationView = (NavigationView) findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(this);
            navigationView.getMenu().getItem(0).setChecked(true);

            //===============main code=================

            //== setting the username for the textview fiels in the navigation drawer==
            TextView tvUser = navigationView.getHeaderView(0).findViewById(R.id.nav_tv_username);
            tvUser.setText(mShared.getString("username", "User name"));

            fngetUnitsList(true);

            //== initializing spinner which calles the functions whenever user selects the devices ==
            //== those functions will updates the ui ==
           unitSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    pd.show();
                    //== this is to check wether the user is in daily or in weekly  depending on that we are calling different functions==
                    try {
                        updateDailyYesterday();
                        if (tvDuration.getText().toString().equals("Daily"))

                            dailyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
                        else if(tvDuration.getText().toString().equals("Weekly"))
                            weeklyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
                        else
                            monthlyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
                    } catch (Exception e) {
                        e.printStackTrace();
                        //== this will trigger when there are not units in the spinner, so i am calling the function to get the spinner elements ==
                        //fngetUnitsList(true);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });



            //== this thread is used to make sure after 50 minutes token is updating ==
            //== here just initialization is done ==
            //== this counter wil starts and stops automatically when the new token createdd and the old token gets invalid ==
            tokenThread = new CountDownTimer(3600000, 25000) {

                @Override
                public void onTick(long millisUntilFinished) {

                }

                @Override
                public void onFinish() {
                    //== flag to control the generation of new token even if its not required ==
                    //== like even if the user enters the other activity it will not generate new tooken untill the olderone gets invalis ==
                    SplashScreenActivity.tokenValid = false;
                    //== function to generate the new token (modified version of the login activity) ==
                    fnGenerateToken();
                }
            };

            //== initalizing swipe refresh layout ==
           srl = findViewById(R.id.swipeLayout);

            //== calling the function which updates the ui when user refreshes==
            srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    pd.show();

                    //== same as above mentioned comments==
                    try {
                        if (tvDuration.getText().toString().equals("Daily"))
                            dailyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
                        else if(tvDuration.getText().toString().equals("Weekly"))
                            weeklyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
                        else if(tvDuration.getText().toString().equals("Monthly"))
                            monthlyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));


//                        tvRefreshTime.setText("Updated on " + unitMap.get(unitSpinner.getSelectedItem().toString()).get("updated_time"));
                    } catch (Exception e) {
                        fngetUnitsList(true);
                    }
                    //== we need to manually removing loading symbol at the top after our work is done
                    srl.setRefreshing(false);
                }
            });

            fnGenerateToken();
            //== for the first time we need to call manually, so calling the same code that i called above ==
            try {
//                updateDailyYesterday();
                Log.d("calling daily api","first time");
                pd.show();
                if (tvDuration.getText().toString().equals("Daily"))
                    dailyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
                else if(tvDuration.getText().toString().equals("Weekly"))
                    weeklyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
                else
                    monthlyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));

            } catch (Exception e) {
                e.printStackTrace();
                Log.d("first fetch","fetching units");
                //fngetUnitsList(true);
                //if (tvDuration.getText().toString().equals("Daily"))
                    //dailyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
            }

        }
    }


    private ArrayList<PointValue> findKeys(String response, String response1, String var, String var1) {
        List<String> keys = new ArrayList<>();
        List<String> lastKeys = new ArrayList<>();

//        Log.i("flow factor", unitMap.get(unitSpinner.getSelectedItem().toString()).get("flow_factor"));

        if(tvDuration.getText().toString().equals("Daily")){

            int time = Integer.parseInt(new SimpleDateFormat("HH").format(new Date()))+1;
            Log.i("check", String.valueOf(time));
            for(int i=time; i>0; i--){
                keys.add(String.valueOf(i)+".0");
                lastKeys.add(String.valueOf(i)+".0");
                Log.i("Daily_keys",keys.get(keys.size()-1));
            }
        }
        else if(tvDuration.getText().toString().equals("Weekly")){

            Calendar cal = Calendar.getInstance();
            for(int i=0; i<7; i++){

                if(( cal.get(cal.MONTH) + 1 )<10)
                    if(cal.get(cal.DATE)<10)
                        keys.add(cal.get(cal.YEAR) + "-0" + ( cal.get(cal.MONTH) + 1 ) + "-0" + cal.get(cal.DATE) );
                    else
                        keys.add(cal.get(cal.YEAR) + "-0" + ( cal.get(cal.MONTH) + 1 ) + "-" + cal.get(cal.DATE) );
                else
                    if(cal.get(cal.DATE)<10)
                        keys.add(cal.get(cal.YEAR) + "-" + ( cal.get(cal.MONTH) + 1 ) + "-0" + cal.get(cal.DATE) );
                    else
                        keys.add(cal.get(cal.YEAR) + "-" + ( cal.get(cal.MONTH) + 1 ) + "-" + cal.get(cal.DATE) );
                Log.i("weekly_keys",keys.get(keys.size()-1));
                cal.add(Calendar.DATE,-1);
            }
            //cal.add(Calendar.DATE,+1);
            for(int i=0; i<7; i++){

                if(( cal.get(cal.MONTH) + 1 )<10)
                    if(cal.get(cal.DATE)<10)
                        lastKeys.add(cal.get(cal.YEAR) + "-0" + ( cal.get(cal.MONTH) + 1 ) + "-0" + cal.get(cal.DATE) );
                    else
                        lastKeys.add(cal.get(cal.YEAR) + "-0" + ( cal.get(cal.MONTH) + 1 ) + "-" + cal.get(cal.DATE) );
                else
                    if(cal.get(cal.DATE)<10)
                        lastKeys.add(cal.get(cal.YEAR) + "-" + ( cal.get(cal.MONTH) + 1 ) + "-0" + cal.get(cal.DATE) );
                    else
                        lastKeys.add(cal.get(cal.YEAR) + "-" + ( cal.get(cal.MONTH) + 1 ) + "-" + cal.get(cal.DATE) );
                Log.i("weekly_keys1",lastKeys.get(lastKeys.size()-1));
                cal.add(Calendar.DATE,-1);
            }

        }
        else if(tvDuration.getText().toString().equals("Monthly")){
            Calendar cal = Calendar.getInstance();
            for(int i=0; i<30; i++){

                if(( cal.get(cal.MONTH) + 1 )<10)
                    if(cal.get(cal.DATE)<10)
                        keys.add(cal.get(cal.YEAR) + "-0" + ( cal.get(cal.MONTH) + 1 ) + "-0" + cal.get(cal.DATE) );
                    else
                        keys.add(cal.get(cal.YEAR) + "-0" + ( cal.get(cal.MONTH) + 1 ) + "-" + cal.get(cal.DATE) );
                else
                    if(cal.get(cal.DATE)<10)
                        keys.add(cal.get(cal.YEAR) + "-" + ( cal.get(cal.MONTH) + 1 ) + "-0" + cal.get(cal.DATE) );
                    else
                        keys.add(cal.get(cal.YEAR) + "-" + ( cal.get(cal.MONTH) + 1 ) + "-" + cal.get(cal.DATE) );
                Log.i("keys",keys.get(keys.size()-1));
                cal.add(Calendar.DATE,-1);
            }

            //cal.add(Calendar.DATE,+1);
            for(int i=0; i<30; i++){

                if(( cal.get(cal.MONTH) + 1 )<10)
                    if(cal.get(cal.DATE)<10)
                        lastKeys.add(cal.get(cal.YEAR) + "-0" + ( cal.get(cal.MONTH) + 1 ) + "-0" + cal.get(cal.DATE) );
                    else
                        lastKeys.add(cal.get(cal.YEAR) + "-0" + ( cal.get(cal.MONTH) + 1 ) + "-" + cal.get(cal.DATE) );
                else
                    if(cal.get(cal.DATE)<10)
                        lastKeys.add(cal.get(cal.YEAR) + "-" + ( cal.get(cal.MONTH) + 1 ) + "-0" + cal.get(cal.DATE) );
                    else
                        lastKeys.add(cal.get(cal.YEAR) + "-" + ( cal.get(cal.MONTH) + 1 ) + "-" + cal.get(cal.DATE) );
                Log.i("keys1",lastKeys.get(lastKeys.size()-1));
                cal.add(Calendar.DATE,-1);
            }
        }
        else{

            int time = Integer.parseInt(new SimpleDateFormat("HH").format(new Date()))+1;
            Log.i("check", String.valueOf(time));


            for(int i=0, j=Integer.valueOf(var);i<24;i++, j=(j+1)%24)
            {
                keys.add(String.valueOf(j)+".0");
                lastKeys.add(String.valueOf(j)+".0");
                Log.i("Daily_keys",keys.get(keys.size()-1));
            }

        }

        HashMap<String, String> userMap = new HashMap<>();
        HashMap<String, String> lastUserMap = new HashMap<>();
        try {
            if(tvDuration.getText().toString().equals("Daily") || tvDuration.getText().toString().equals("Weekly") || tvDuration.getText().toString().equals("Monthly")) {
                JSONArray units = new JSONObject(response).getJSONArray("data");
                for (int i = 0; i < units.length(); i++) {
                    userMap.put(units.getJSONObject(i).keys().next(), units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("process_consumption"));

                }
            }else{
                JSONArray units = new JSONObject(response).getJSONObject("data").getJSONArray("units");
                for (int i = 0; i < units.length(); i++) {

                        userMap.put(units.getJSONObject(i).getString("hour"), units.getJSONObject(i).getString("process_consumption"));

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {

            if(tvDuration.getText().toString().equals("Daily") || tvDuration.getText().toString().equals("Weekly") || tvDuration.getText().toString().equals("Monthly")) {
                JSONArray units = new JSONObject(response1).getJSONArray("data");
                for(int i=0; i<units.length(); i++){
                    lastUserMap.put(units.getJSONObject(i).keys().next(), units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("process_consumption"));

                }
           }
           else{
                JSONArray units = new JSONObject(response1).getJSONObject("data").getJSONArray("units");
                for(int i=0; i<units.length(); i++){
                        lastUserMap.put(units.getJSONObject(i).getString("hour"), units.getJSONObject(i).getString("process_consumption"));

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }




        ArrayList<PointValue> values = new ArrayList<>();
        try {

            //== entries stores the values  and labels stores the x axis values ==
            JSONArray items;
            if(tvDuration.getText().toString().equals("Daily") || tvDuration.getText().toString().equals("Weekly") || tvDuration.getText().toString().equals("Monthly")) {
                items = new JSONObject(response).getJSONArray("data");
            }
            else{
                items = new JSONObject(response).getJSONObject("data").getJSONArray("units");
            }
            ArrayList<BarEntry> entries=new ArrayList<>();
            ArrayList<String> labels =new ArrayList<>();

            ArrayList<BarEntry> entries1=new ArrayList<>();

            if(tvDuration.getText().toString().equals("Daily") || tvDuration.getText().toString().equals("Weekly") || tvDuration.getText().toString().equals("Monthly")) {
                for (int i = keys.size() - 1, j = 0; i >= 0; i--, j++) {

                    try {
                        float val = 0f;
                        if (userMap.containsKey(keys.get(i))) {
                            val = Float.parseFloat(userMap.get(keys.get(i))) / 1000 /** Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("flow_factor"))*/;
                            if (val == 0) val = 0f;
                        }
                        float val1 = 0f;
                        if (lastUserMap.containsKey(lastKeys.get(i))) {
                            val1 = Float.parseFloat(lastUserMap.get(lastKeys.get(i))) / 1000 /** Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("flow_factor"))*/;
                            if (val == 0) val = 0f;
                        }
                        if (tvDuration.getText().toString().equals("Daily"))
                            labels.add(keys.get(i).replace(".0", ""));
                        else if (tvDuration.getText().toString().equals("Weekly") || tvDuration.getText().toString().equals("Monthly"))
                            labels.add(lastKeys.get(i).split("-")[2] + "/" + lastKeys.get(i).split("-")[1] + " | " + keys.get(i).split("-")[2] + "/" + keys.get(i).split("-")[1]);
                        else
                            labels.add(keys.get(i).replace(".0", ""));
                        if (userMap.containsKey(keys.get(i)))
                            entries.add(new BarEntry(val, j));
                        if (lastUserMap.containsKey(lastKeys.get(i)))
                            entries1.add(new BarEntry(val1, j));
                        Log.i("check", String.valueOf(val));
                        Log.i("check1", String.valueOf(val1));
                    } catch (Exception e) {
                        Log.i("gs error", e.getMessage());
                    }
                }
            }else{

                for (int i = 0, j = 0; i <keys.size() ; i++, j++) {

                    try {
                        float val = 0f;
                        if (userMap.containsKey(keys.get(i))) {
                            val = Float.parseFloat(userMap.get(keys.get(i))) / 1000 /** Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("flow_factor"))*/;
                            if (val == 0) val = 0f;
                        }
                        float val1 = 0f;
                        if (lastUserMap.containsKey(lastKeys.get(i))) {
                            val1 = Float.parseFloat(lastUserMap.get(lastKeys.get(i))) / 1000 /** Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("flow_factor"))*/;
                            if (val == 0) val = 0f;
                        }
                        if (tvDuration.getText().toString().equals("Daily"))
                            labels.add(keys.get(i).replace(".0", ""));
                        else if (tvDuration.getText().toString().equals("Weekly") || tvDuration.getText().toString().equals("Monthly"))
                            labels.add(lastKeys.get(i).split("-")[2] + "/" + lastKeys.get(i).split("-")[1] + " | " + keys.get(i).split("-")[2] + "/" + keys.get(i).split("-")[1]);
                        else
                            labels.add(keys.get(i).replace(".0", ""));
                        entries.add(new BarEntry(val, j));
                        entries1.add(new BarEntry(val1, j));
                        Log.i("check", String.valueOf(val));
                        Log.i("check1", String.valueOf(val1));
                    } catch (Exception e) {
                        Log.i("gs error", e.getMessage());
                    }
                }

            }
            //=======barChart parameters===============
            barChartWeely = findViewById(R.id.barchart);
            BarDataSet bardataset = null,bardataset1 = null;
            if(tvDuration.getText().toString().equals("Daily")){
                bardataset = new BarDataSet(entries, "Today's      Daily Consumption in Kilo Liters");
                bardataset1 = new BarDataSet(entries1, "Yesterday's");
            } else if(tvDuration.getText().toString().equals("Weekly")){
                bardataset = new BarDataSet(entries, "Present Week    Weekly Consumption in Kilo Liters");
                bardataset1 = new BarDataSet(entries1, "Last Week  |");
            } else if(tvDuration.getText().toString().equals("Monthly")){
                bardataset = new BarDataSet(entries, "Present Month     Monthly Consumption in Kilo Liters");
                bardataset1 = new BarDataSet(entries1, "Last Month  |");
            } else{
                bardataset = new BarDataSet(entries, tvDuration.getText().toString()+"      Daily Consumption in Kilo Liters");
                bardataset1 = new BarDataSet(entries1, mShared.getString("date2",""));
            }

            bardataset.setBarSpacePercent(0f);
            bardataset1.setBarSpacePercent(0f);
            bardataset.setHighlightEnabled(false);
            bardataset1.setHighlightEnabled(false);
            BarData data1 = new BarData(labels);
            data1.addDataSet(bardataset1);
            data1.addDataSet(bardataset);
            data1.setGroupSpace(100);
            data1.setValueTextSize(8f);
            data1.setHighlightEnabled(false);
            bardataset.setColor(Color.argb(215,45,95,117));
            bardataset1.setColor(Color.argb(155,64, 190,237));

            barChartWeely.setData(data1);
            barChartWeely.getXAxis().setDrawGridLines(false);
            barChartWeely.getAxisLeft().setEnabled(false);
            barChartWeely.getAxisLeft().setDrawGridLines(false);
            barChartWeely.setDescription("");  // set the description
            barChartWeely.animateY(1000);
            barChartWeely.animateX(1000);
            barChartWeely.getAxisRight().setEnabled(false);
            barChartWeely.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
            barChartWeely.getXAxis().setTextSize(7f);
            barChartWeely.getXAxis().setLabelsToSkip(0);
            barChartWeely.setVisibleXRangeMaximum(16.5f);
            barChartWeely.setVisibleXRangeMinimum(16.5f);
            barChartWeely.enableScroll();
            data1.setValueFormatter(new MyValueFormatter());

            barChartWeely.moveViewToX(3*items.length()+6);
            barChartWeely.setFocusableInTouchMode(false);
            barChartWeely.setPinchZoom(false);
            barChartWeely.setDoubleTapToZoomEnabled(false);
            barChartWeely.setSelected(false);

            //=========== setting legend position============
            Legend l1 = barChartWeely.getLegend();
            l1.setPosition(Legend.LegendPosition.BELOW_CHART_RIGHT);
            l1.setForm(Legend.LegendForm.SQUARE);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return  values;

    }

    //== this function will fetch the units list for the spinner ==
    //== flag parameter is to avoid the adding of spinner elements again and again even if its there==
    //== i mean once the spinner elements get loaded no need of loading again ==
    //== from second time only data gets loaded not spinner ==
    private void fngetUnitsList(final boolean flag) {


        String BASE_URL = "http://54.71.150.252/aquagen/v1/industries/";
        String url = BASE_URL + mShared.getString("industryid",null) + "/units";
        url = url.replaceAll(" ","%20");


        //==api call==
        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        Log.i("loading internal units",response);

                        //== logic after getting the api response ==
                        //== here units list gets updated only if tr is no units in the spinner ==
                        //== mMap is user to create a map of one units data==
                        //== usermap is a map of maps like 2d array which stores the data off all the units ==
                        //== the time getting from the api iis convertde into 12 hour format using manual logic and removing GMT tag at the end and storing ==

                        try {
                            JSONArray units = new JSONObject(response).getJSONArray("data");
                            if(flag == true) unitsList.clear();
                            for(int i=0;i<units.length();i++){
                                if(flag == true )
                                    unitsList.add(units.getJSONObject(i).getString("unit_name"));
                                HashMap<String, String> mMap = new HashMap<>();
                                mMap.put("unit_name", units.getJSONObject(i).getString("unit_name"));
                                mMap.put("flow_factor", units.getJSONObject(i).getString("flow_factor"));
                                mMap.put("height", units.getJSONObject(i).getString("height"));
                                mMap.put("unit_id", units.getJSONObject(i).getString("unit_id"));

                                unitMap.put(units.getJSONObject(i).getString("unit_name"), mMap);

                                //fnGetLatestData(units.getJSONObject(i).getString("unit_id"));
                                //fnUpdatedTime(units.getJSONObject(i).getString("unit_id"));

                                //== only when all the units get loaded we are updating the ui and spinner ==
                                //== we are not supposed to write outside the for loop because of multi threading==
                                if(i == units.length()-1 && flag == true) {
                                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, unitsList);
                                    unitSpinner.setAdapter(arrayAdapter);
                                    pd.show();
                                }
                                }
                                fnGetLatestData();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        pd.dismiss();
                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                pd.dismiss();
                handleError(error);
//                Log.i("error message  gs1",error.getMessage());

                /*ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {
                    //Toast.makeText(getApplicationContext(), "Sorry, no response from the server\nTry again after some time...", Toast.LENGTH_LONG).show();
                } else {

                    internet.setVisibility(View.GONE);
                    noInternet.setVisibility(View.VISIBLE);
                    tvRefreshTime.setVisibility(View.GONE);
                    //Toast.makeText(getApplicationContext(),"No internet connection...\nPlease connect to internet",Toast.LENGTH_LONG).show();
                    return;

                }*/

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };
        RequestQueue requestQueue_total= Volley.newRequestQueue(getApplicationContext());
        stringRequest_total.setRetryPolicy(new DefaultRetryPolicy(

                60000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT )    );
        requestQueue_total.add(stringRequest_total);

    }

    private void fnGetLatestData() {

        pd.show();
        //== api call ==
        String BASE_URL = "http://54.71.150.252/aquagen/v1/industries/";
        String url = BASE_URL + mShared.getString("industryid", null) + "/consumption/latest?category=Internal Source&unit_id="+unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id");
        url = url.replaceAll(" ", "%20");

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

//                        Log.i("level", "Response is:" + response);
                        pd.dismiss();
                        try {
                            JSONArray units = new JSONObject(response).getJSONObject("data").getJSONArray("units");
                            if (units.length()== 0) {
                                tvToday.setText("");
                                fnGetLastUpdatedTime();
                            } else {

                                Log.i("control here","updated time else");
                                for (int i = 0; i < units.length(); i++) {
                                    try {
                                        HashMap<String, String> mMap = new HashMap<>();
                                        mMap.put("consumption", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("consumption"));
                                        mMap.put("process_consumption", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("process_consumption"));
                                        mMap.put("flow_factor", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("flow_factor"));
                                        mMap.put("height", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("height"));
                                        mMap.put("max_capacity", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("max_capacity"));
                                        mMap.put("unit_id", units.getJSONObject(i).keys().next());
                                        String time = units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("created_on");
                                        time = time.replace("GMT", "");
                                        int val = Integer.parseInt(time.substring(time.indexOf(":") - 2, time.indexOf(":")));
                                        int temp = val;
                                        if (val > 11 && val != 12){
                                            val = val - 12;
                                            time = time.substring(0, time.indexOf(":") - 2) + String.valueOf(val) + time.substring(time.indexOf(":"));
                                        }
                                        else if(val == 12){
                                            val = 12;
                                            time = time.substring(0, time.indexOf(":") - 2) + String.valueOf(val) + time.substring(time.indexOf(":"));
                                        }
                                        if (temp < 12) time += " AM";
                                        else time += "PM";

                                        mMap.put("updated_time", time);
                                        unitMap.put(units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("unit_name"), mMap);


                                        if (i == units.length() - 1) {

                                            try {
                                                tvRefreshTime.setText("Updated on " + unitMap.get(unitSpinner.getSelectedItem().toString()).get("updated_time"));
                                            } catch (Exception e) {
//                                        fngetUnitsList(true);
                                            }
                                        }

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                //pd.dismiss();
                handleError(error);

            }

        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };
        stringRequest_total.setShouldCache(true);

        RequestQueue requestQueue_total = Volley.newRequestQueue(getApplicationContext());
        requestQueue_total.add(stringRequest_total);
    }


    private void fnGetLastUpdatedTime() {

        //pd.show();
        //== api call ==
        String BASE_URL = "http://54.71.150.252/aquagen/v1/industries/";
        String url = BASE_URL + mShared.getString("industryid", null) + "/consumption/lastupdated?unit_id=" + unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id");
        url = url.replaceAll(" ", "%20");

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

//                        Log.i("last_updated", "Response is:" + response);
                        pd.dismiss();
                        try {
                            JSONArray data = new JSONObject(response).getJSONArray("data");
                            //unitsList.clear();
                            for (int i = 0; i < data.length(); i++) {

                                Log.i("control here1","unit id");

                                HashMap<String, String> mMap = new HashMap<>();
                                mMap.put("unit_id", data.getJSONObject(i).keys().next());
                                mMap.put("unit_name",data.getJSONObject(i).getJSONObject(data.getJSONObject(i).keys().next()).getString("unit_name"));

                                String time = data.getJSONObject(i).getJSONObject(data.getJSONObject(i).keys().next()).getString("last_updated_on");
                                time = time.replace("GMT", "");
                                int val = Integer.parseInt(time.substring(time.indexOf(":") - 2, time.indexOf(":")));
                                int temp = val;
                                if (val > 11 && val != 12){
                                    val = val - 12;
                                    time = time.substring(0, time.indexOf(":") - 2) + String.valueOf(val) + time.substring(time.indexOf(":"));

                                }

                                else if( val == 12){
                                    time = time.substring(0, time.indexOf(":") - 2) + String.valueOf(val) + time.substring(time.indexOf(":"));

                                }

                                if (temp < 12) time += " AM";
                                else time += "PM";

                                mMap.put("last_updated_on", time);
                                unitMap.put(data.getJSONObject(i).getJSONObject(data.getJSONObject(i).keys().next()).getString("unit_name"), mMap);

                                if (i == data.length()-1) {
                                    //Log.i("display last_updated", unitMap.get(unitSpinner.getSelectedItem().toString()).get("last_updated_on"));
                                    tvRefreshTime.setText("Last Updated On " + unitMap.get(unitSpinner.getSelectedItem().toString()).get("last_updated_on"));
                                }
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                //pd.dismiss();
                handleError(error);
//                Log.i("error message  gs",error.getMessage());
             /*   ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {
                    Toast.makeText(getApplicationContext(), "Sorry, no response from the server\nTry again after some time...", Toast.LENGTH_LONG).show();
                } else {

                    internet.setVisibility(View.GONE);
                    noInternet.setVisibility(View.VISIBLE);
                    //Toast.makeText(getApplicationContext(),"No internet connection...\nPlease connect to internet",Toast.LENGTH_LONG).show();
                    return;

                }*/
            }

        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };
        stringRequest_total.setShouldCache(true);

        RequestQueue requestQueue_total = Volley.newRequestQueue(getApplicationContext());
        requestQueue_total.add(stringRequest_total);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Are you sure you want to exit?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            MainActivity.this.finishAffinity();
                            /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                MainActivity.this.finishAndRemoveTask();
                            }*/
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The act
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_daily){

            //== checking for the internet connectivity ==
            ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
            if (activeNetwork != null && activeNetwork.isConnected()) {


            } else {

                internet.setVisibility(View.GONE);
                noInternet.setVisibility(View.VISIBLE);
                tvRefreshTime.setVisibility(View.GONE);
                //Toast.makeText(getApplicationContext(),"No internet\nPlease check your connection....",Toast.LENGTH_LONG).show();
                return super.onOptionsItemSelected(item);
            }
            fnGenerateToken();

            tvDuration.setText("Daily");
            pd.show();
            //== same logic as mentioned above ==
            try {
                dailyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
            }catch(Exception e){
                fngetUnitsList(true);
            }
//            pd.dismiss();
        }

        else if( id == R.id.action_weekly) {

            //== checking internet connectivity ==
            ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
            if (activeNetwork != null && activeNetwork.isConnected()) {


            } else {

                internet.setVisibility(View.GONE);
                noInternet.setVisibility(View.VISIBLE);
                tvRefreshTime.setVisibility(View.GONE);
                //Toast.makeText(getApplicationContext(),"No internet\nPlease check your connection....",Toast.LENGTH_LONG).show();
                return super.onOptionsItemSelected(item);
            }
            fnGenerateToken();


            tvDuration.setText("Weekly");
            pd.show();
            //== same as the above mentioned logic ==
            try {
                weeklyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
            }catch(Exception e){
                fngetUnitsList(true);
            }
//            pd.dismiss();
        }
        else if( id == R.id.action_monthly) {

            //== checking internet connectivity ==
            ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
            if (activeNetwork != null && activeNetwork.isConnected()) {


            } else {

                internet.setVisibility(View.GONE);
                noInternet.setVisibility(View.VISIBLE);
                tvRefreshTime.setVisibility(View.GONE);
                //Toast.makeText(getApplicationContext(),"No internet\nPlease check your connection....",Toast.LENGTH_LONG).show();
                return super.onOptionsItemSelected(item);
            }
            fnGenerateToken();


            tvDuration.setText("Monthly");
            pd.show();
            //== same as the above mentioned logic ==
            try {
                monthlyApi(unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id"));
            }catch(Exception e){
                fngetUnitsList(true);
            }
//            pd.dismiss();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();

        //== at first after splashScreenActivity user will enter into mainActivity only ==
        //== if he is not signed in in earlier we are redirecting the user to login activity ==
        //== we not we are checcking for internet connectivity ==
        //== and since user is opening for the first we are generating the token directly ==
        if(!mShared.getBoolean("flag",false))
        {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
        }
        else{

            ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
            if (activeNetwork != null && activeNetwork.isConnected()) {


            } else {

                internet.setVisibility(View.GONE);
                noInternet.setVisibility(View.VISIBLE);
                tvRefreshTime.setVisibility(View.GONE);
                //Toast.makeText(getApplicationContext(),"No internet\nPlease check your connection....",Toast.LENGTH_LONG).show();
                return;
            }
            fnGenerateToken();

        }
    }

    //== this user defined function is to generate the token dynamically when ever it is required ==
    //== this is modified version of LoginActivity.java ==
    public void fnGenerateToken(){

        if(SplashScreenActivity.tokenValid) return;

        tokenThread.cancel();
        tokenThread.start();

        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Username", mShared.getString("username",""));
            jsonObject.put("password", mShared.getString("password",""));

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, JSON_URL, jsonObject, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

//                    Log.i("response of loginAPI", String.valueOf(response));
                    JSONObject data = null;

                    try {

                        data = response.getJSONObject("data");
                        String ID = data.getString("industry_id");
                        String token = data.getString("token");
                        mShared.edit().putString("token", token).apply();
                        mShared.edit().putString("industryid", ID).apply();
                        String status = response.getString("status");
                        pd.dismiss();

                        SplashScreenActivity.tokenValid = true;

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //Log.i("error", "error ocuured");

                    pd.dismiss();
                    handleError(error);
                    return;
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
//                            headers.put("Content-Type", "application/json");
                    String credentials = mShared.getString("username","") + ":" + mShared.getString("password","");
                    //String credentials = String.format(username.getText().toString(),password.getText().toString());
                    Log.i("Display", credentials);
                    String auth = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                    Log.i("Display generated auth", auth);
                    //headers.put("Authorization", "Basic ZGFyc2hhbmFrYXZ5YUBnbWFpbC5jb206dGVzdDEyMzQ=");
                    headers.put("Authorization", auth);
                    return headers;
                }
            };
            requestQueue.add(jsonObjectRequest);

        } catch (JSONException e) {
            pd.dismiss();
            e.printStackTrace();
        }

    }

    //== we are not using this because wwe have our own customized navigation drawer, instead of this we are writing all these codes in the onCLick(0 overridden method ==
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if( id == R.id.nav_but_contactus)
        {
            View view2= View.inflate(getApplicationContext(), R.layout.contactus, null);
            final Dialog dia = new Dialog(this);
            dia.setContentView(view2);


            TextView tv = view2.findViewById(R.id.tvContactAddress);
            tv.setText(Html.fromHtml("<br><br><span style=\"font-size:140%\"><b>Address : </b></span> Fluxgen Engineering Technologies<br>#1064, 1st floor, 18th Main<br>2nd Stage,BTM Layout<br>Bangalore 560076"));


            view2.findViewById(R.id.btCall).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:08042033298"));
                    startActivity(intent);
                }
            });

            dia.setOnKeyListener(new DialogInterface.OnKeyListener() {
                @Override
                public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                    if(keyCode == KeyEvent.KEYCODE_BACK){
                        startActivity(new Intent(MainActivity.this,MainActivity.class));
                        finish();
                    }
                    return true;
                }
            });

            Button cancelButton = view2.findViewById(R.id.cancelButton);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dia.dismiss();

                }
            });

            dia.show();
            dia.setCancelable(true);

        }
        else if( id == R.id.nav_but_about){
            startActivity(new Intent( MainActivity.this , AboutUs.class));
        }
        else if( id == R.id.nav_but_home){
            //navigationView.getMenu().getItem(id).setChecked(true);


        }
        else if( id == R.id.nav_but_level){
            startActivity(new Intent(MainActivity.this, levelActivity.class));
        }
        else if( id == R.id.nav_but_noti){
            Intent intent = new Intent(MainActivity.this, NotificationList.class);
            intent.putExtra("pop_up_notification_flag",false);
            startActivity(intent);
        }
        else if( id == R.id.nav_but_milk){
            startActivity(new Intent(MainActivity.this, MilkActivity.class));
        }
        else if( id == R.id.nav_but_shift){
            startActivity(new Intent(MainActivity.this, ShiftActivity.class));
        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    void updateDailyYesterday() {


        new Thread(new Runnable() {
            @Override
            public void run() {



                long to = new Date().getTime()/1000;
                long from = to - to%86400 + 1800;
                String url1 = "http://54.71.150.252/aquagen/v1/industries/" + mShared.getString("industryid", null) + "/consumption/" +
                        "report?duration=hourlyreport&unit_id=" + unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id")+"&createdAfter="+from + "&createdBefore="+to;
                url1 = url1.replaceAll(" ", "%20");
                Log.i("report url", url1);

                StringRequest stringRequest_total1 = new StringRequest(Request.Method.GET, url1,
                        new Response.Listener<String>() {

                            @Override
                            public void onResponse(String response) {


                                Log.i("report response", response);
                                JSONObject unit = null;
                                try {
                                    unit = new JSONObject(response).getJSONObject("data");
                                    float val = /*Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("flow_factor"))**/  Float.parseFloat(unit.getString("total_consumption"));
                                    if(val<1000){
                                        tvToday.setText(String.valueOf((int)val));
                                    }
                                    else if(val<1000000){
                                        tvToday.setText(String.valueOf(val/1000.0)+"K");
                                    }else {
                                        int temp = (int)val/1000;
                                        tvToday.setText(String.valueOf(temp/1000.0)+"M");
                                    }


                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();
                        handleError(error);

                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() {

                        HashMap<String, String> headers = new HashMap<>();
                        headers.put("Content-Type", "application/json");
                        headers.put("Authorization", mShared.getString("token", "invalid token.."));
                        return headers;
                    }
                };
                RequestQueue requestQueue_total1 = Volley.newRequestQueue(getApplicationContext());
                stringRequest_total1.setRetryPolicy(new DefaultRetryPolicy(

                        60000,
                        0,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                requestQueue_total1.add(stringRequest_total1);


            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {

                long to = new Date().getTime()/1000;
                to = to - to%86400 + 1800;
                long from = to-86400;
                String url1 = "http://54.71.150.252/aquagen/v1/industries/" + mShared.getString("industryid", null) + "/consumption/" +
                        "report?duration=hourlyreport&unit_id=" + unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id")+"&createdAfter="+from + "&createdBefore="+to;
                url1 = url1.replaceAll(" ", "%20");
                Log.i("report url", url1);

                StringRequest stringRequest_total1 = new StringRequest(Request.Method.GET, url1,
                        new Response.Listener<String>() {

                            @Override
                            public void onResponse(String response) {


                                Log.i("report response", response);
                                JSONObject unit = null;
                                try {
                                    unit = new JSONObject(response).getJSONObject("data");
                                    float val = /*Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("flow_factor"))**/  Float.parseFloat(unit.getString("total_consumption"));
                                    if(val<1000){
                                        tvYesterday.setText(String.valueOf((int)val));
                                    }
                                    else if(val<1000000){
                                        tvYesterday.setText(String.valueOf(val/1000.0)+"K");
                                    }else {
                                        int temp = (int)val/1000;
                                        tvYesterday.setText(String.valueOf(temp/1000.0)+"M");
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();
                        handleError(error);

                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() {

                        HashMap<String, String> headers = new HashMap<>();
                        headers.put("Content-Type", "application/json");
                        headers.put("Authorization", mShared.getString("token", "invalid token.."));
                        return headers;
                    }
                };
                RequestQueue requestQueue_total1 = Volley.newRequestQueue(getApplicationContext());
                stringRequest_total1.setRetryPolicy(new DefaultRetryPolicy(

                        60000,
                        0,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                requestQueue_total1.add(stringRequest_total1);

            }
        }).start();
    }


    //== this user defined function is to get the daily data and set the daily graph ==
    public void dailyApi(final String unit_id )  {

        //updating the data of all the units only not the sinner
        fngetUnitsList(false);
        updateDailyYesterday();
        String url = "http://54.71.150.252/aquagen/v1/industries/"+mShared.getString("industryid",null)+
                "/consumption/graph?duration=daily&unit_id="+unit_id;
        url = url.replaceAll(" ","%20");
    //==========daily graph==========================

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(final String response) {
//                        Log.i("daily graph",response);
                        //== calling the function to set the graph ==
    //                        fnSetData(response,"", "daily");

                        String url = "http://54.71.150.252/aquagen/v1/industries/"+mShared.getString("industryid",null)+
                                "/consumption/graph?duration=yesterday&unit_id="+unit_id;
                        url = url.replaceAll(" ","%20");

                        //==========daily graph==========================

                        StringRequest stringRequest_total2 = new StringRequest(Request.Method.GET, url,
                                new Response.Listener<String>() {

                                    @Override
                                    public void onResponse(String response1) {
                                        pd.dismiss();
                                        JSONArray unit = null;

//                                        Log.i("yesterday graph",response1);
                                        //== calling the function to set the graph ==
                                        try {
                                            /*unit = new JSONObject(response1).getJSONArray("data");
                                            for(i=unit.length();i== unit.length();i--){
                                                unit.getJSONObject(i).getString("total_consumption");
//                                            fnSetData(response,response1,tvDuration.getText().toString())
                                            };*/
                                            findKeys(response, response1, "consumption", "consumption");
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                    }

                                }, new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError error) {
                                pd.dismiss();
                                handleError(error);
                            }
                        }) {
                            @Override
                            public Map<String, String> getHeaders() {

                                HashMap<String, String> headers = new HashMap<>();
                                headers.put("Content-Type", "application/json");
                                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                                return headers;
                            }
                        };

                        RequestQueue requestQueue_total2= Volley.newRequestQueue(getApplicationContext());
                        stringRequest_total2.setRetryPolicy(new DefaultRetryPolicy(

                                60000,
                                0,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT )    );
                        requestQueue_total2.add(stringRequest_total2);

                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                pd.dismiss();
                handleError(error);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };

        //== since at the begining daily graph was taking more time  setted its maxium time as 30 secnds to get the response from the server ==
        //== this thing is done only here ==
        stringRequest_total.setRetryPolicy(new DefaultRetryPolicy(

                    60000,
                            0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT )    );
        RequestQueue requestQueue_total= Volley.newRequestQueue(getApplicationContext());
            requestQueue_total.add(stringRequest_total);

    }

    //== this user defined fntion is the get the weekly data and set the weekly graph ==
    //== but this will work for monthly also, since we dont have monthly right now i given the name as weekly ==
    public void weeklyApi(final String unit_id ){

        //== getting only units data notupdating the spinner ==
        fngetUnitsList(false);
        updateDailyYesterday();
        pd.show();
        //=============graph weekly api=================
        //== here we are using the response of this api to set tehe value of the graph as well a stoo get the todays and yesterdays consmption==
        String url = "http://54.71.150.252/aquagen/v1/industries/"+mShared.getString("industryid",null)+
                "/consumption/graph?duration=weekly&unit_id="+unit_id;
        url = url.replaceAll(" ","%20");

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(final String response) {



//                        Log.i("weekly graph", response);
                        String url = "http://54.71.150.252/aquagen/v1/industries/"+mShared.getString("industryid",null)+
                                "/consumption/graph?duration=lastweek&unit_id="+unit_id;
                        url = url.replaceAll(" ","%20");
                        Log.i("urls",url);
                        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                                new Response.Listener<String>() {

                                    @Override
                                    public void onResponse(String response1) {

//                                        Log.i("last week graph", response1);
                                        try {
//                                                fnSetData(response,response1,tvDuration.getText().toString());
                                            findKeys(response, response1,"consumption", "consumption");
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                    }

                                }, new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError error) {
                                pd.dismiss();
                                handleError(error);
                            }
                        }) {
                            @Override
                            public Map<String, String> getHeaders() {

                                HashMap<String, String> headers = new HashMap<>();
                                headers.put("Content-Type", "application/json");
                                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                                return headers;
                            }
                        };

                        RequestQueue requestQueue_total= Volley.newRequestQueue(getApplicationContext());
                        stringRequest_total.setRetryPolicy(new DefaultRetryPolicy(

                                60000,
                                0,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT )    );
                        requestQueue_total.add(stringRequest_total);


                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                pd.dismiss();
                handleError(error);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };

        RequestQueue requestQueue_total= Volley.newRequestQueue(getApplicationContext());
        stringRequest_total.setRetryPolicy(new DefaultRetryPolicy(

                60000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT )    );
        requestQueue_total.add(stringRequest_total);

    }

    public void monthlyApi(final String unit_id ){

        //== getting only units data notupdating the spinner ==
        fngetUnitsList(false);
        updateDailyYesterday();
        pd.show();
        //=============graph weekly api=================
        //== here we are using the response of this api to set tehe value of the graph as well a stoo get the todays and yesterdays consmption==
        String url = "http://54.71.150.252/aquagen/v1/industries/"+mShared.getString("industryid",null)+
                "/consumption/graph?duration=monthly&unit_id="+unit_id;
        url = url.replaceAll(" ","%20");

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(final String response) {


//                        Log.i("weekly graph", response);
                        String url = "http://54.71.150.252/aquagen/v1/industries/"+mShared.getString("industryid",null)+
                                "/consumption/graph?duration=lastmonth&unit_id="+unit_id;
                        url = url.replaceAll(" ","%20");
                        Log.i("urls1",url);
                        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                                new Response.Listener<String>() {

                                    @Override
                                    public void onResponse(String response1) {

//                                        Log.i("last weekly graph", response1);
                                        try {
//                                            fnSetData(response,response1,tvDuration.getText().toString());
                                            findKeys(response, response1,"consumption", "consumption");
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                    }

                                }, new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError error) {
                                pd.dismiss();
                                handleError(error);

                            }
                        }) {
                            @Override
                            public Map<String, String> getHeaders() {

                                HashMap<String, String> headers = new HashMap<>();
                                headers.put("Content-Type", "application/json");
                                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                                return headers;
                            }
                        };

                        RequestQueue requestQueue_total= Volley.newRequestQueue(getApplicationContext());
                        stringRequest_total.setRetryPolicy(new DefaultRetryPolicy(

                                60000,
                                0,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT )    );
                        requestQueue_total.add(stringRequest_total);

                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                pd.dismiss();
                handleError(error);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };

        RequestQueue requestQueue_total= Volley.newRequestQueue(getApplicationContext());
        stringRequest_total.setRetryPolicy(new DefaultRetryPolicy(

                60000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT )    );
        requestQueue_total.add(stringRequest_total);

    }




    @Override
    protected void onRestart() {
        super.onRestart();

        fnGenerateToken();
    }

    @Override
    protected void onPause() {
        super.onPause();
        fnGenerateToken();
    }

    @Override
    protected void onResume() {
        super.onResume();
        fnGenerateToken();
    }


    private void handleError(VolleyError error) {


        if(error instanceof NoConnectionError){
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = null;
            if (cm != null) {
                activeNetwork = cm.getActiveNetworkInfo();
            }
            if(activeNetwork != null && activeNetwork.isConnectedOrConnecting()){
                /*Toast.makeText(MainActivity.this
                        , "Server is not connected to internet.",
                        Toast.LENGTH_SHORT).show();*/
            } else {

                internet.setVisibility(View.GONE);
                noInternet.setVisibility(View.VISIBLE);
                tvRefreshTime.setVisibility(View.GONE);

                Toast.makeText(MainActivity.this
                        , "Your device is not connected to internet.",
                        Toast.LENGTH_SHORT).show();
            }
        }
        else if (error instanceof NetworkError)
        {
            Toast.makeText(MainActivity.this
                    , " Network connection lost. Please check your connectivity.",
                    Toast.LENGTH_SHORT).show();
        }
       /* else if (error instanceof NetworkError || error.getCause() instanceof ConnectException
                || (error.getCause().getMessage() != null
                && error.getCause().getMessage().contains("connection")))
        {
            Toast.makeText(MainActivity.this
                    , " Network connection lost. Please check your connectivity.",
                    Toast.LENGTH_SHORT).show();
        }*/
        else if (error.getCause() instanceof MalformedURLException)
        {

            Toast.makeText(MainActivity.this
                    , "Bad Request.", Toast.LENGTH_SHORT).show();
        }
        else if (error instanceof ParseError || error.getCause() instanceof IllegalStateException
                || error.getCause() instanceof JSONException
                || error.getCause() instanceof XmlPullParserException)
        {

            Toast.makeText(MainActivity.this
                    , "Parse Error (because of invalid json or xml).",
                    Toast.LENGTH_SHORT).show();
        }
        else if (error.getCause() instanceof OutOfMemoryError)
        {

            Toast.makeText(MainActivity.this
                    , "Your device is out of Memory.", Toast.LENGTH_SHORT).show();
        }
        else if (error instanceof AuthFailureError)
        {

            Toast.makeText(MainActivity.this
                    , "server couldn't find the authenticated request.",
                    Toast.LENGTH_SHORT).show();
        }
        else if (error instanceof ServerError || error.getCause() instanceof ServerError)
        {

            Toast.makeText(MainActivity.this
                    , "Server is not responding.Please Contact Administrator.", Toast.LENGTH_SHORT).show();
        }
        else if (error instanceof TimeoutError || error.getCause() instanceof SocketTimeoutException
                || error.getCause() instanceof ConnectTimeoutException
                || error.getCause() instanceof SocketException
                )
        {
//            Log.i("printing socket error", String.valueOf(error.networkResponse.statusCode));
//            Toast.makeText(MainActivity.this
//                    , "Very slow internet connection.",
//                    Toast.LENGTH_SHORT).show();
        }
        else
            {
                Toast.makeText(MainActivity.this
                    , "An unknown error occurred.",
                    Toast.LENGTH_SHORT).show();
        }

    }

}
