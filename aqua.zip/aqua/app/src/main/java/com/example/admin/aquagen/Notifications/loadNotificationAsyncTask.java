package com.example.admin.aquagen.Notifications;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.admin.aquagen.R;

import org.json.JSONException;
import org.json.JSONObject;

import de.hdodenhof.circleimageview.CircleImageView;

public class loadNotificationAsyncTask extends AsyncTask<Void, LinearLayout, Void> {


    private LinearLayout listLayout;
    private Context context;
    private SharedPreferences mShared;
    //CircleImageView circleImageView;


    //== this constructor will receive context and the required reference in order to add the notificatins layout into the main layout one by one dynamically ==
    public loadNotificationAsyncTask(LinearLayout listLayout, Context context){
        this.listLayout = listLayout;
        this.context = context;
        mShared = context.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);
    }


    //== here we are constructing the notification message from the notification data which is saved in json format as it is in the shared preferences ==
    //== this function will call publishProgress() after building each single new notification layout ==
    //== here what we are doing is, we are inflating the single_notification_layout and setting all the values and adding into  the actual layout ==
    @Override
    protected Void doInBackground(Void... voids) {

        Log.i("count",String.valueOf(mShared.getInt("notiCount"+ mShared.getString("industryid",""),0)));
        listLayout.removeAllViews();
        for(int i = mShared.getInt("notiCount"+ mShared.getString("industryid",""),0)-1; i >=0; i--) {


            View v = View.inflate(context, R.layout.single_notification_layout, null);
            LinearLayout layout = v.findViewById(R.id.rllll);


            //==this logic will generate the formatted message according to our requirement ==
            try {
                JSONObject json = new JSONObject(mShared.getString("Noti"+ mShared.getString("industryid","") + String.valueOf(i + 1), ""));

                if(!json.getJSONObject(json.keys().next()).getString("industryid").equals(mShared.getString("industryid","")))
                    continue;

                Log.i("json", json.toString());

                TextView tvTime = v.findViewById(R.id.tvNotiTime);
                TextView tvTitle = v.findViewById(R.id.tvNotiTitle);
                tvTime.setText(mShared.getString("Noti"+ mShared.getString("industryid","") + String.valueOf(i + 1) + "time", ""));
                Log.i("time title",mShared.getString("Noti"+ mShared.getString("industryid","") + String.valueOf(i + 1) + "time", ""));
                Log.i("list title","Noti"+ mShared.getString("industryid","") + String.valueOf(i + 1) + "time");
                TextView body = v.findViewById(R.id.tvNotiBody);
                StringBuilder msg = new StringBuilder("Below mentioned devices has reached the threshold...\n\n");
                String noti_timestamp = json.getJSONObject(json.keys().next()).getString("timestamp");
                for(int j=0;j<json.length();j++){

                    if(json.getJSONObject(String.valueOf(j)).has("level")) {
                        CircleImageView circleImageView = v.findViewById(R.id.circleImageView);
                        circleImageView.setImageResource(R.drawable.level1);
                        tvTitle.setText("Level Alert");
                        float floatValue = Float.parseFloat(json.getJSONObject(String.valueOf(j)).getString("level"));
                        floatValue /= 30.48;
                        msg.append(j+1).append(". ").append(json.getJSONObject(String.valueOf(j)).getString("devicename") /*+ "   level = " + floatValue*/).append(" has reached 85% of threshold value at this time ").append(noti_timestamp).append("\n Please take required action to prevent overflow. ").append("\n");
                    }else if(json.getJSONObject(String.valueOf(j)).has("flow")) {
                        CircleImageView circleImageView = v.findViewById(R.id.circleImageView);
                        circleImageView.setImageResource(R.drawable.aquagenlogo2);
                        tvTitle.setText("Flow Alert");
                        float floatValue = Float.parseFloat(json.getJSONObject(String.valueOf(j)).getString("flow"));
                        floatValue /= 30.48;
                        floatValue /= 1000;
                        msg.append(j+1).append(". ").append(json.getJSONObject(String.valueOf(j)).getString("devicename")/* + "   consumption = " + floatValue */).append(" has reached its consumption limit at this time ").append(noti_timestamp).append("\n");
                    }
                }
                body.setText(msg.toString());

                //== publishing the progress to the user interface ==
                publishProgress(layout);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return null;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
    }

    //== this will add that notification into the user interface dynamically ==
    @Override
    protected void onProgressUpdate(LinearLayout... values) {
        listLayout.addView(values[0]);
    }
}
