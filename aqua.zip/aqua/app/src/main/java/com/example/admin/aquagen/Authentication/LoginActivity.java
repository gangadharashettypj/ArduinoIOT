package com.example.admin.aquagen.Authentication;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.admin.aquagen.Home.MainActivity;
import com.example.admin.aquagen.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {



    private String JSON_URL = "http://54.71.150.252/aquagen/v1/auth/login";
    public String token = "";
    private ProgressDialog pd;

    private Button submit;
    private TextInputEditText username, password;
    private LinearLayout noInternet, internet;
    private Button retryInternet;
    private SharedPreferences mShared;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mShared = this.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);
        noInternet = findViewById(R.id.noInternetLoginLayout);
        internet = findViewById(R.id.internetLoginLayout);
        retryInternet = findViewById(R.id.btRetryLogin);
        retryInternet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {

                    internet.setVisibility(View.VISIBLE);
                    noInternet.setVisibility(View.GONE);

                } else {

                    internet.setVisibility(View.GONE);
                    noInternet.setVisibility(View.VISIBLE);
                    Toast.makeText(getApplicationContext(),"No internet found...\nPlease switch on the internet and then retry",Toast.LENGTH_LONG).show();
                    return;

                }

            }
        });




        TextView tvTitle =findViewById(R.id.tvTitle);
        tvTitle.setText(Html.fromHtml("Login to <font color=\"#0986c1\">Aqua</font><font color=\"#698e3c\">Gen</font>"),TextView.BufferType.SPANNABLE);



//        ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
//        if (activeNetwork != null && activeNetwork.isConnected()) {
//
//
//        } else {
//
//            internet.setVisibility(View.GONE);
//            noInternet.setVisibility(View.VISIBLE);
//
////            Snackbar snackbar = Snackbar.make(findViewById(R.id.tet_user_name),"No internet connection...\nPlease connect to internet", Snackbar.LENGTH_LONG)
////                    .setAction("RETRY", new View.OnClickListener() {
////                        @Override
////                        public void onClick(View view) {
////                            startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
////                        }
////                    });
////            snackbar.show();
//        }


        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);



        pd = new ProgressDialog(LoginActivity.this);
        pd.setTitle("Loging in!");
        pd.setMessage("Please wait...");
        pd.setCanceledOnTouchOutside(false);

        submit = findViewById(R.id.btSubmit);
        username = findViewById(R.id.tet_user_name);
        password = findViewById(R.id.tet_password);
        final ImageButton passVisi = findViewById(R.id.ibtVisibility);

        passVisi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("visibility", String.valueOf(password.getInputType()));
                if(password.getInputType() == 129) {
                    password.setInputType(145);
                    passVisi.setImageDrawable(getResources().getDrawable(R.drawable.ic_visibility_off_black_24dp));
                }
                else {
                    password.setInputType(129);
                    passVisi.setImageDrawable(getResources().getDrawable(R.drawable.ic_visibility_black_24dp));
                }
            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(), "Displaying credentials" + username.getText().toString() + password.getText().toString(), Toast.LENGTH_LONG).show();
                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();

                if(username.getText().toString().length()==0 && password.getText().toString().length()==0)
                {
                    Snackbar.make(findViewById(R.id.tet_user_name),"User name and Password are not entered....", Snackbar.LENGTH_LONG)
                            .show();
                    return;
                }else if(username.getText().toString().length()==0)
                {
                    Snackbar.make(findViewById(R.id.tet_user_name),"User name not entered....", Snackbar.LENGTH_LONG)
                            .show();
                    return;
                }
                else if(password.getText().toString().length()==0)
                {
                    Snackbar.make(findViewById(R.id.tet_user_name),"Password not entered....", Snackbar.LENGTH_LONG)
                            .show();
                    return;
                }
                else if(password.getText().toString().length()<6)
                {
                    Snackbar.make(findViewById(R.id.tet_user_name),"Minimum length of password must be 6....", Snackbar.LENGTH_LONG)
                            .show();
                    return;
                }


                if (activeNetwork != null && activeNetwork.isConnected()) {


                } else {


                    Snackbar snackbar = Snackbar.make(findViewById(R.id.tet_user_name),"No internet connection...\nPlease connect to internet", Snackbar.LENGTH_LONG)
                            .setAction("RETRY", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
                                }
                            });
                    snackbar.show();
                    return;
                }

                pd.show();
                final RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("Username", username.getText().toString());
                    jsonObject.put("password", password.getText().toString());

                    JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, JSON_URL, jsonObject, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            Log.i("response of loginAPI", String.valueOf(response));
                            JSONObject data = null;


                            try {
                                data = response.getJSONObject("data");
                                String ID = data.getString("industry_id");
                                token = data.getString("token");
                                mShared.edit().putString("token", token).apply();
                                mShared.edit().putString("industryid", ID).apply();
                                String status = response.getString("status");
                                Log.i("Industry Id: ", ID);
                                Log.i("User token: ", token);
                                Log.i("Status: ", status);
                                pd.dismiss();

                                mShared.edit().putString("username",username.getText().toString()).apply();
                                mShared.edit().putString("password",password.getText().toString()).apply();
                                mShared.edit().putBoolean("flag",true).apply();
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            //Log.i( "error msg status code", String.valueOf(error.networkResponse.statusCode));
                            if(error.networkResponse.statusCode == 401){
                                Snackbar.make(findViewById(R.id.tet_user_name),"Invalid Credentials", Snackbar.LENGTH_LONG)
                                       .show();

                            }
                            else if(error.networkResponse.statusCode == 503){
                                Snackbar.make(findViewById(R.id.tet_user_name),"Server is temporarily down ", Snackbar.LENGTH_LONG)
                                        .show();
                            }
                            else if(error.networkResponse.statusCode == 502){
                                Snackbar.make(findViewById(R.id.tet_user_name),"Server got invalid response, Please Try again.. ", Snackbar.LENGTH_LONG)
                                        .show();

                            }else if(error.networkResponse.statusCode == 500){
                                Snackbar.make(findViewById(R.id.tet_user_name),"There is an internal server issue. Please Contact Administrator. ", Snackbar.LENGTH_LONG)
                                        .show();
                            }

                            ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                            NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                            if (activeNetwork != null && activeNetwork.isConnected()) {
                                //Toast.makeText(getApplicationContext(), "Sorry, no response from the server\nTry again after some time...", Toast.LENGTH_LONG).show();
                            } else {

                                Snackbar snackbar = Snackbar.make(findViewById(R.id.tet_user_name),"No internet connection...\nPlease connect to internet", Snackbar.LENGTH_LONG)
                                        .setAction("RETRY", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
                                            }
                                        });
                                snackbar.show();
                                return;

                            }
                            pd.dismiss();

                        }
                    })
                    {
                        @Override
                        public Map<String, String> getHeaders() throws AuthFailureError {
                            HashMap<String, String> headers = new HashMap<String, String>();
//                            headers.put("Content-Type", "application/json");
                            String credentials = username.getText().toString() + ":" + password.getText().toString();
                            //String credentials = String.format(username.getText().toString(),password.getText().toString());
                            Log.i("Display", credentials);
                            String auth = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                            Log.i("Display generated auth", auth);
                            //headers.put("Authorization", "Basic ZGFyc2hhbmFrYXZ5YUBnbWFpbC5jb206dGVzdDEyMzQ=");
                            headers.put("Authorization", auth);
                            return headers;
                        }

                        @Override
                        protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                            Log.i("print response", String.valueOf(response));
                            return super.parseNetworkResponse(response);
                        }
                    };
                    requestQueue.add(jsonObjectRequest);
                } catch (JSONException e) {
                    pd.dismiss();
                    e.printStackTrace();
                }
            }

        });

    }
}
