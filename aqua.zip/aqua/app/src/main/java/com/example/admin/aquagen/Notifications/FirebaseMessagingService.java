package com.example.admin.aquagen.Notifications;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.example.admin.aquagen.R;
import com.example.admin.aquagen.SplashScreenActivity;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;




//== some notes related to notifications in in notifications_offline_storage_structure.txt file in the package structure_of_the_logic==
public class FirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {
    String TAG="FirebaseMessagingService";

    private Context mContext;
    private NotificationManager mNotificationManager;
    private NotificationCompat.Builder mBuilder,mBuilder1,mBuilder2,summary_mbuilder;
    private Notification notification1;
    private int summary_id = 1;
    private Notification notification2;
    private Notification summary_notification;
    //private Notification notification1,notification2,summary_notification;

    private Notification.InboxStyle inboxStyle;


    private static final String NOTIFICATION_ID="1";
    private static int value = 0;
    public static final String GROUP_NOTIFICATIONS ="NOTIFICATIONS";
    public static final String NOTIFICATION_CHANNEL_ID = "1";
    public static final String NOTIFICATION_CHANNEL_NAME = "ANDROID CHANNEL";


    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        Log.d(TAG, "From: " + remoteMessage.getData().toString());

        mContext = getApplicationContext();

        //== initalizing the shared preference bec when wee opened the notifications directly we are not going through splashscreenactivity
        //== so we need to initalize those variables which are initialized in that activity ==
        SharedPreferences mShared = this.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);

        try {
            //== if the notification belongs to the current logged in industry then only showing the notificaations.  In all other cases just storing==
            if (new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid").startsWith(mShared.getString("industryid", ""))&& mShared.getBoolean("notification_switcher",true))
                createNotification("Aquagen alerts!", remoteMessage.getData().get("default"));

            mShared.edit().putInt("notiCount"+ new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid"),mShared.getInt("notiCount"+ new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid"),0)+1).apply();
            mShared.edit().putString("Noti"+ new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid")+String.valueOf(mShared.getInt("notiCount"+ new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid"),0)),remoteMessage.getData().get("default")).apply();
            mShared.edit().putString("Noti"+ new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid")+String.valueOf(mShared.getInt("notiCount"+ new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid"),0))+"time",new SimpleDateFormat("dd/MM/yyyy  hh:mm  a").format(new Date()).replaceAll("p.m","P.M").replaceAll("a.m","A.M")).apply();
            Log.i("msg title","Noti"+ new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid")+String.valueOf(mShared.getInt("notiCount"+ new JSONObject(remoteMessage.getData().get("default")).getJSONObject(new JSONObject(remoteMessage.getData().get("default")).keys().next()).getString("industryid"),0))+"time");
        }catch(Exception e){

        }

    }

    @Override
    public void onMessageSent(String msgId) {
        // ...
        Toast.makeText(getApplicationContext(),"Message sent Sucessfully", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSendError(String msgId, Exception e) {
        // ...
        Toast.makeText(getApplicationContext(),"Message not sent Sucessfully",Toast.LENGTH_SHORT).show();
    }

    //== this userdefined function will generatee the notification for the received messaage in the mobile ==
   public void createNotification(String title, String message)
    {
        int numMessages =0;
        /**Creates an explicit intent for an Activity in your app**/
        Intent resultIntent = new Intent(mContext , NotificationList.class);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);


        PendingIntent resultPendingIntent = PendingIntent.getActivity(mContext, 0 , resultIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);

        mBuilder = new NotificationCompat.Builder(mContext);
        //mBuilder.setSmallIcon(R.drawable.aquagenlogo1);
//        mBuilder.setLargeIcon(Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.aquagenlogo1),200,300,false));
        mBuilder.setContentTitle(title)
                .setAutoCancel(true)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .setSmallIcon(R.drawable.aquagenlogo1)
                .setContentIntent(resultPendingIntent)
                .setStyle(new NotificationCompat.BigTextStyle().setBigContentTitle("Aquagen Alerts!")
                        .bigText(getMesssage(message)))
                .setChannelId(NOTIFICATION_CHANNEL_ID)
                .setGroup(GROUP_NOTIFICATIONS)
                .setNumber(++numMessages)
                .setPriority(NotificationManager.IMPORTANCE_HIGH);


        try {
            if(new JSONObject(message).getJSONObject("0").has("level"))
                mBuilder.setContentText("Level alert!");
            else if(new JSONObject(message).getJSONObject("0").has("flow"))
                mBuilder.setContentText("Flow alert!");

        } catch (JSONException e) {
            e.printStackTrace();
        }

        mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);

        summary_notification = new NotificationCompat.Builder(mContext, NOTIFICATION_CHANNEL_ID)
                        .setContentTitle(title)
                        //set content text to support devices running API level < 24
                        .setSmallIcon(R.drawable.aquagenlogo1)
                        .setContentIntent(resultPendingIntent)
                        //build summary info into InboxStyle template
                        .setStyle(new NotificationCompat.InboxStyle()
                                .setBigContentTitle("Aquagen Alerts!")
                                .addLine(getMesssage(message)))
                        //specify which group this notification belongs to
                        .setGroup(GROUP_NOTIFICATIONS)
                        .setAutoCancel(true)
                        //set this notification as the summary for the group
                        .setGroupSummary(true)
                        .build();

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, NOTIFICATION_CHANNEL_NAME, importance);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            assert mNotificationManager != null;
            mBuilder.setContentTitle(title);
            mBuilder.setSmallIcon(R.drawable.aquagenlogo1);
            mBuilder.setAutoCancel(true);
            mBuilder.setSound(Settings.System.DEFAULT_NOTIFICATION_URI);
            mBuilder.setContentIntent(resultPendingIntent);
            mBuilder.setNumber(++numMessages);
            mBuilder.setStyle(new NotificationCompat.BigTextStyle().setBigContentTitle("Aquagen Alerts!").bigText(getMesssage(message)));
            mBuilder.setChannelId(NOTIFICATION_CHANNEL_ID);
            mBuilder.setGroup(GROUP_NOTIFICATIONS);
            //mBuilder.setChannelId((String.valueOf(new Date().getTime())));


             summary_notification =
                    new NotificationCompat.Builder(mContext, NOTIFICATION_CHANNEL_ID)
                            .setContentTitle(title)
                            //set content text to support devices running API level < 24
                            .setSmallIcon(R.drawable.aquagenlogo1)
                            .setContentIntent(resultPendingIntent)
                            .setAutoCancel(true)
                            //build summary info into InboxStyle template
                            .setStyle(new NotificationCompat.InboxStyle()

                                    .setBigContentTitle("Aquagen Alerts!")
                                    .addLine(getMesssage(message)))
                            //specify which group this notification belongs to
                            .setGroup(GROUP_NOTIFICATIONS)
                            //set this notification as the summary for the group
                            .setGroupSummary(true)
                            .build();

            mNotificationManager.createNotificationChannel(notificationChannel);
        }

        assert mNotificationManager != null;
        //mBuilder.build().flags |= Notification.FLAG_AUTO_CANCEL;
        //mBuilder.getNotification().flags |= Notification.FLAG_AUTO_CANCEL;

        //mNotificationManager.notify(NOTIFICATION_CHANNEL_ID,(int)(new Date().getTime()), mBuilder.build());
        //mNotificationManager.notify(m, mBuilder.build());
        SystemClock.sleep(2000);

        mNotificationManager.notify((int)(new Date().getTime()), mBuilder.build());
        SystemClock.sleep(4000);
        mNotificationManager.notify(2,summary_notification);

    }








    //== this user define method will parse the message received in the notifications and organizes into the required format like...==
    //== if the number of device  is one then one kind of structure else another ==
    //== and returns a fully formatted String which is to be displayed in the notifications ==
    public String getMesssage(String data){

        try{
            JSONObject json = new JSONObject(data);
            Log.i("dvice",json.getJSONObject(json.keys().next()).getString("devicename"));
            Log.i("noti_timestamp",json.getJSONObject(json.keys().next()).getString("timestamp"));
            String noti_timestamp = json.getJSONObject(json.keys().next()).getString("timestamp");

            //SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a");
            //SimpleDateFormat simpleDateFormat = new SimpleDateFormat();

            //noti_timestamp = simpleDateFormat.format(new Date()).toString();
            //System.out.println(noti_timestamp);

            StringBuilder msg = new StringBuilder("Below mentioned devices has reached the threshold...\n\n");
            for(int j=0;j<json.length();j++){

                if(json.getJSONObject(String.valueOf(j)).has("level")) {
                    float floatValue = Float.parseFloat(json.getJSONObject(String.valueOf(j)).getString("level"));
                    floatValue /= 30.48;
                    msg.append(j+1).append(". ").append(json.getJSONObject(String.valueOf(j)).getString("devicename")/* + "   level = " + floatValue */).append(" has reached 85% of threshold value at this time ").append(noti_timestamp).append("\n Please take required action to prevent overflow. ").append("\n");
                }else if(json.getJSONObject(String.valueOf(j)).has("flow")) {
                    float floatValue = Float.parseFloat(json.getJSONObject(String.valueOf(j)).getString("flow"));
                    floatValue /= 30.48;
                    floatValue /= 1000;
                    msg.append(j+1).append(". ").append(json.getJSONObject(String.valueOf(j)).getString("devicename") /*+ "   consumption = " + floatValue */).append(" has reached its consumption limit at this time ").append(noti_timestamp).append("\n");
                }
            }
            return msg.toString();
        }
        catch (Exception e){

        }
        return "";
    }
}
