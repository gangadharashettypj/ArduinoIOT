package com.example.admin.aquagen.Info;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.widget.TextView;

import com.example.admin.aquagen.Home.MainActivity;
import com.example.admin.aquagen.R;

public class AboutUs extends AppCompatActivity {

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        getSupportActionBar().setTitle("About us");
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        TextView tvTitle =findViewById(R.id.tv_title_about_us);
        tvTitle.setText(Html.fromHtml("<font color=\"#0986c1\">Aqua</font><font color=\"#698e3c\">Gen</font>"),TextView.BufferType.SPANNABLE);

//        WebView webView = findViewById(R.id.webView);
//        webView.loadUrl("file:///android_asset/about.html");

        TextView tvAbout = findViewById(R.id.tvAbout);
        tvAbout.setText(    Html.fromHtml("<span style=\"text-align:justify; font-size:150%\">\n" +
                "Industries, being unaware about  water consumption would hinder their production. AquaGen is a water monitoring solution that helps in preventing collosal loss in industries. Unlike other water monitoring solutions, AquaGen offers an intuitive and insightful report about consumption.\n" +
                "</span>")
        );

    }

    @Override
    public void onBackPressed()
    {
        startActivity(new Intent(AboutUs.this,MainActivity.class));
        super.onBackPressed();
    }

    
}
