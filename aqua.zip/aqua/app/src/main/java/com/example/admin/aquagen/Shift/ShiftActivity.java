package com.example.admin.aquagen.Shift;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.example.admin.aquagen.Authentication.LoginActivity;
import com.example.admin.aquagen.HTTP_GET.GetApi;
import com.example.admin.aquagen.Home.MainActivity;
import com.example.admin.aquagen.Info.AboutUs;
import com.example.admin.aquagen.Level.levelActivity;
import com.example.admin.aquagen.MilkActivity;
import com.example.admin.aquagen.Notifications.NotificationList;
import com.example.admin.aquagen.R;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.view.PieChartView;

public class ShiftActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static PieChartView pieChart;
    private static TextView tvDuration;
    private SharedPreferences mShared;
    private LinearLayout mChartLegend;
    private static SwipeRefreshLayout srl_shift;
    public static String GET_API_RESPONSE;
    private static ProgressDialog pd;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shift);
        try {

            initReferences();


        } finally {


            //==============Setting progress dialog properties====================
            pd = new ProgressDialog(ShiftActivity.this);
            pd.setTitle("Loading!");
            pd.setMessage("Please wait...");
            pd.setCanceledOnTouchOutside(false);
            pd.setCancelable(false);


            tvDuration.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (tvDuration.getText().toString().equals("Daily") || tvDuration.getText().toString().equals("Weekly") || tvDuration.getText().toString().equals("Monthly"))
                        return;

                    Log.i("year", "clicked");

                    Calendar cal = Calendar.getInstance();
                    cal.add(cal.DATE, -1);
                    Log.i("showing date", cal.getTime().toString());
                    try {

                        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, final int year, final int month, final int dayOfMonth) {


                                new TimePickerDialog(ShiftActivity.this, new TimePickerDialog.OnTimeSetListener() {
                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                                        Calendar c = Calendar.getInstance();
                                        c.set(year, month, dayOfMonth, hourOfDay, minute);
                                        Date date = c.getTime();

                                        String show = new SimpleDateFormat("MMM").format(date) + " " + dayOfMonth + ", " + hourOfDay + ":00";

                                        tvDuration.setText(show);
                                        mShared.edit().putString("date1", show).apply();
                                        mShared.edit().putString("fromShiftTimestamp", String.valueOf((int) (date.getTime() / 1000))).apply();
                                        srl_shift.setRefreshing(true);
                                        new GetApi(ShiftActivity.this, "temp")
                                                .getDataFromUrl(


                                                        mChartLegend,
                                                        "http://54.71.150.252/aquagen/v1/industries/" + mShared.getString("industryid", null) +
                                                                "/consumption/report?duration=hourly&category=Internal%20Source"
                                                                + "&createdAfter=" + String.valueOf((int) (date.getTime() / 1000)) + "&createdBefore="
                                                                + String.valueOf(((int) (date.getTime() / 1000)) + 86400)
                                                );
                                    }
                                }, 6, 0, true).show();


                            }
                        };


                        DatePickerDialog dat = new DatePickerDialog(ShiftActivity.this, dateSetListener, cal.get(cal.YEAR), cal.get(cal.MONTH), cal.get(cal.DAY_OF_MONTH));
                        dat.getDatePicker().setMaxDate(cal.getTimeInMillis());

                        dat.show();


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });


            srl_shift.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    srl_shift.setRefreshing(true);
                    fnRefreshContents();
                    srl_shift.setRefreshing(false);
                }
            });

            Calendar cal = Calendar.getInstance();
            cal.add(cal.DATE, -1);
            Date date = cal.getTime();
            String da[] = date.toString().split(" ");
            cal.add(cal.DATE, -1);
            date = cal.getTime();
            String da1[] = date.toString().split(" ");
            String show = da[1] + " " + da[2] + ", " + da[3].split(":")[0] + ":00";
            String show1 = da1[1] + " " + da1[2];
            tvDuration.setText(show);
            mShared.edit().putString("date1", show).apply();
            mShared.edit().putString("date2", show1).apply();
            mShared.edit().putString("fromShiftTimestamp", String.valueOf((int) (date.getTime() / 1000 + 3600 * 0.5))).apply();

            pd.show();
            fnRefreshContents();


        }


    }

    private void fnRefreshContents() {


        new GetApi(ShiftActivity.this, "temp")
                .getDataFromUrl(
                        mChartLegend,
                        "http://54.71.150.252/aquagen/v1/industries/" + mShared.getString("industryid", null) +
                                "/consumption/report?duration=hourly&category=Internal%20Source"
                                + "&createdAfter=" + mShared.getString("fromShiftTimestamp", ((new Date().getTime() / 86400) * 86400) + "") + "&createdBefore="
                                + (Integer.parseInt(mShared.getString("fromShiftTimestamp", String.valueOf((new Date().getTime() / 86400) * 86400 + 86400))) + 86400)
                );


    }


    private void initReferences() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.getMenu().getItem(3).setChecked(true);


        mShared = this.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);
        //== setting the username for the textview fiels in the navigation drawer==
        TextView tvUser = navigationView.getHeaderView(0).findViewById(R.id.nav_tv_username);
        tvUser.setText(mShared.getString("username", "User name"));

        pieChart = findViewById(R.id.mPieChart);
        mChartLegend = findViewById(R.id.pieChartLegend);

        tvDuration = toolbar.findViewById(R.id.tv_shift_type);


        srl_shift = findViewById(R.id.srl_shift);


        //== seeing the action for log out button in the navigation drawer ==
        //== naming convention is same as mentioned in the above comment ==
        findViewById(R.id.logout_navigation_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //== checking for internet connection ==
                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {


                } else {

//                    internet.setVisibility(View.GONE);
//                    noInternet.setVisibility(View.VISIBLE);
//                    tvRefreshTime.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), "No internet connection...\nPlease connect to internet", Toast.LENGTH_LONG).show();
                    return;

                }

                //== clearing all the notificatins of older account ==
//                    for(int i=0; i <mShared.getInt("notiCount"+ mShared.getString("industryid",""),0); i++) {
//                        mShared.edit().remove("Noti"+ mShared.getString("industryid","")+String.valueOf(i+1)).apply();
//                    }
//                    mShared.edit().remove("notiCount"+ mShared.getString("industryid","")).apply();


                //== getting user name and password==
                mShared.edit().putString("username", "").apply();
                mShared.edit().putString("password", "").apply();

                //== setting the flag as false bec we are generating token automatically when it becomes invalid ==
                //== when ever user signouts plase take care aboiut this flag in all sides which is in all the activities ==
                mShared.edit().putBoolean("flag", false).apply();

                //== when user signouts we need to remove its subscription from the topic he subscribed, otherwise he may get the notification for older industry after signing with other industry also ==
                //== all the code related to aws sns notification we need to write in seperate threads==
                //== and some points are same as i mentioned above ==
                new Thread(new Runnable() {
                    public void run() {
                        try {


                            BasicAWSCredentials credentials = new BasicAWSCredentials("AKIAJVZ3GEMCA6FOZIBA", "iLHUghd95toLaYyOOVrCFCtxcTWxVO8LUEN13OCW");

                            Log.i("token", FirebaseInstanceId.getInstance().getToken());

                            //create a new SNS client and set endpoint
                            AmazonSNSClient snsClient = new AmazonSNSClient(credentials);
                            snsClient.setRegion(Region.getRegion(Regions.US_WEST_2));

                            Log.i("endpoint unsub", snsClient.getEndpoint());


                            //== function call for unsubscribing==
//                                snsClient.unsubscribe(mShared.getString("subscriptionArn",""));


                            //==this is not required , this will delete the entire aquagen application from the web ==
                            //== so i commented (dont use)
//                                DeletePlatformApplicationRequest dpar = new DeletePlatformApplicationRequest()
//                                        .withPlatformApplicationArn("arn:aws:sns:us-west-2:685446373664:app/GCM/Aquagen");
//
//                                snsClient.deletePlatformApplication(dpar);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();

                //== after signout we are going to loginactivity again==
                startActivity(new Intent(ShiftActivity.this, LoginActivity.class));
                finish();
            }
        });


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            startActivity(new Intent(ShiftActivity.this, MainActivity.class));
            super.onBackPressed();
        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.nav_but_contactus) {
            View view2 = View.inflate(getApplicationContext(), R.layout.contactus, null);
            final Dialog dia = new Dialog(this);
            dia.setContentView(view2);


            TextView tv = view2.findViewById(R.id.tvContactAddress);
            tv.setText(Html.fromHtml("<br><br><span style=\"font-size:140%\"><b>Address : </b></span> Fluxgen Engineering Technologies<br>#1064, 1st floor, 18th Main<br>2nd Stage,BTM Layout<br>Bangalore 560076"));


            view2.findViewById(R.id.btCall).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:08042033298"));
                    startActivity(intent);
                    finish();
                }
            });

            dia.setOnKeyListener(new DialogInterface.OnKeyListener() {
                @Override
                public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                    if (keyCode == KeyEvent.KEYCODE_BACK) {
//                        startActivity(new Intent(ShiftActivity.this,MainActivity.class));
//                        finish();
//                        finish();
                    }
                    return true;
                }
            });

            Button cancelButton = view2.findViewById(R.id.cancelButton);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dia.dismiss();

                }
            });

            dia.show();
            dia.setCancelable(true);

        } else if (id == R.id.nav_but_about) {
            startActivity(new Intent(ShiftActivity.this, AboutUs.class));
            finish();
        } else if (id == R.id.nav_but_home) {
            //navigationView.getMenu().getItem(id).setChecked(true);
            startActivity(new Intent(ShiftActivity.this, MainActivity.class));
            finish();

        } else if (id == R.id.nav_but_level) {
            startActivity(new Intent(ShiftActivity.this, levelActivity.class));
            finish();
        } else if (id == R.id.nav_but_noti) {
            Intent intent = new Intent(ShiftActivity.this, NotificationList.class);
            intent.putExtra("pop_up_notification_flag", false);
            startActivity(intent);
            finish();
        } else if (id == R.id.nav_but_milk) {
            startActivity(new Intent(ShiftActivity.this, MilkActivity.class));
            finish();
        } else if (id == R.id.nav_but_shift) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    @SuppressLint("NewApi")
    public static void updatePieChartUI(LinearLayout mChartLegend, Context mContext) {
        srl_shift.setRefreshing(false);
        pd.dismiss();
        List<Integer> mColor = new ArrayList<>();
        mColor.add(Color.GREEN);
        mColor.add(Color.YELLOW);
        mColor.add(Color.RED);
        mColor.add(Color.BLUE);
        mColor.add(Color.MAGENTA);
        mColor.add(Color.DKGRAY);

        HashMap<String, String> userMap = new HashMap<>();
        try {
            JSONArray units = new JSONObject(GET_API_RESPONSE).getJSONObject("data").getJSONArray("units");

            for (int i = 0; i < units.length(); i++) {
                try {
                    if (units.getJSONObject(i).getString("process_consumption").equals("null"))
                        continue;
                    Log.i("ui value" + i, units.getJSONObject(i).getInt("process_consumption") + "");
                    if (userMap.containsKey(units.getJSONObject(i).getString("unit_name")))
                        userMap.put(
                                units.getJSONObject(i).getString("unit_name"),
                                (Integer.parseInt(userMap.get(units.getJSONObject(i).getString("unit_name"))) + units.getJSONObject(i).getInt("process_consumption")) + ""
                        );
                    else
                        userMap.put(
                                units.getJSONObject(i).getString("unit_name"),
                                units.getJSONObject(i).getInt("process_consumption") + ""
                        );
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


            List<SliceValue> values = new ArrayList<SliceValue>();

            List<String> unitsList = new ArrayList<>();
            unitsList = new ArrayList<>(userMap.keySet());

            int[] COLORS = new int[]{
                    Color.parseColor("#1BA5B0"),
                    Color.parseColor("#E7B430"),
                    Color.parseColor("#C8585F"),
                    Color.parseColor("#229461"),
                    Color.parseColor("#9752A3")
//                    Color.parseColor("#4E90D9"),

            };

            mChartLegend.removeAllViews();
            for (int i = 0; i < unitsList.size(); ++i) {

                SliceValue sliceValue = new SliceValue(Float.parseFloat(userMap.get(unitsList.get(i))), COLORS[i % 5]);
                sliceValue.setLabel(unitsList.get(i));
                values.add(sliceValue);

                LinearLayout rowLayout = (LinearLayout) View.inflate(mContext, R.layout.single_row_pie_chart_legend, null);
                ((TextView) rowLayout.findViewById(R.id.tvPieSerial)).setText(String.valueOf(i + 1));
                int val = Integer.parseInt(userMap.get(unitsList.get(i))) / 1000;
                ((TextView) rowLayout.findViewById(R.id.tvPieConsumption)).setText(val + " KL");
                ((TextView) rowLayout.findViewById(R.id.tvPieUnitsList)).setText(unitsList.get(i));

                mChartLegend.addView(rowLayout);

            }
            PieChartData data = new PieChartData(values);

            pieChart.setValueTouchEnabled(false);
            data.setValueLabelTextSize(10);
            data.setHasLabels(true);
            data.setHasLabelsOutside(true);
            data.setSlicesSpacing(0);
            data.setHasCenterCircle(true);
            data.setCenterText1(tvDuration.getText().toString().split(",")[0]);
            data.setCenterText2(tvDuration.getText().toString().split(",")[1].replace(" ", ""));
            data.setValueLabelsTextColor(Color.argb(255, 31, 66, 82));
            data.setValueLabelBackgroundEnabled(false);
            data.setCenterCircleScale(0.98f);
            pieChart.setCircleFillRatio(0.70f);
            pieChart.setAlpha(1);
            pieChart.setPieChartData(data);
            pieChart.setChartRotationEnabled(false);
            //pieChart.setDefaultFocusHighlightEnabled(false);
            pieChart.setValueSelectionEnabled(false);
            pieChart.setFocusable(false);
            pieChart.setFocusableInTouchMode(false);
            //pieChart.setRevealOnFocusHint(false);


        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}
