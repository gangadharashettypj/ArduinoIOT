package com.example.admin.aquagen.HTTP_GET;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.widget.LinearLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.admin.aquagen.Home.MainActivity;
import com.example.admin.aquagen.Shift.ShiftActivity;

import java.util.HashMap;
import java.util.Map;

public class GetApi {

    private Context mContext;
    private String mResponse;
    private SharedPreferences mShared;
    private String varShared;

    public GetApi(Context mContext, String varShared){
        this.mContext = mContext;
        this.mShared = mContext.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);
        this.mResponse = "";
        this.varShared = varShared;
    }

    synchronized public String getDataFromUrl(final LinearLayout mLayout, final String url){

        ConnectivityManager conMgr = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
        if (activeNetwork != null && activeNetwork.isConnected()) {



        } else {



        }

        Log.i("GetApi, URL", url);

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {



                        Log.i("my_api_response", response);

                        mResponse = response;

                        mShared.edit().putString(varShared, response).apply();
                        ShiftActivity.GET_API_RESPONSE = response;
                        ShiftActivity.updatePieChartUI(mLayout, mContext);


                    }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                error.printStackTrace();


            }

        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };
        RequestQueue requestQueue_total = Volley.newRequestQueue(mContext);
        stringRequest_total.setRetryPolicy(new DefaultRetryPolicy(

                60000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT )    );
        requestQueue_total.add(stringRequest_total);

        return mResponse;
    }


}
