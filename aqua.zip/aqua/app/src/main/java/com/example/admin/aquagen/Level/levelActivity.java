package com.example.admin.aquagen.Level;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.admin.aquagen.Authentication.LoginActivity;
import com.example.admin.aquagen.Home.MainActivity;
import com.example.admin.aquagen.Info.AboutUs;
import com.example.admin.aquagen.MilkActivity;
import com.example.admin.aquagen.Notifications.NotificationList;
import com.example.admin.aquagen.R;
import com.example.admin.aquagen.Shift.ShiftActivity;
import com.example.admin.aquagen.SplashScreenActivity;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParserException;

import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class levelActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private  NavigationView navigationView;
    private LineChart mChart;
    private ProgressDialog pd;
    private SwipeRefreshLayout srl;
    private HashMap<String, HashMap<String,String>> unitMap;
    private List<String> unitsList;
    private Spinner unitSpinner, unitLimitSpinner;
    private TextView tvTotal, tvRefreshTime;
    private DrawerLayout drawer;
    private LinearLayout noInternet, internet;
    private Button retryInternet;
    private SharedPreferences mShared;
    private String JSON_URL = "http://54.71.150.252/aquagen/v1/auth/login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mShared = this.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);
        noInternet = findViewById(R.id.noInternetLevelLayout);
        internet = findViewById(R.id.internetLevelLayout);
        retryInternet = findViewById(R.id.btRetryLevel);
        retryInternet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {

                    internet.setVisibility(View.VISIBLE);
                    noInternet.setVisibility(View.GONE);

                } else {

                    internet.setVisibility(View.GONE);
                    noInternet.setVisibility(View.VISIBLE);
                    Toast.makeText(getApplicationContext(),"No internet found...\nPlease switch on the internet and then retry",Toast.LENGTH_LONG).show();
                    return;

                }
            }
        });

        if(MainActivity.tokenThread==null)
            MainActivity.tokenThread = new CountDownTimer(3600000, 25000) {

                @Override
                public void onTick(long millisUntilFinished) {

                }

                @Override
                public void onFinish() {
                    SplashScreenActivity.tokenValid = false;
                    fnGenerateToken();
                }
            };

        fnGenerateToken();

        //== getting text view reference updated time==
        tvRefreshTime = findViewById(R.id.tvCurrent_Time2);
        //== text view reference for total liters value ==
        tvTotal = findViewById(R.id.tvTotalValue);
        //== spinner reference for selecting different devices
        unitSpinner = findViewById(R.id.sp_level);

        unitMap = new HashMap<>();
        unitsList = new ArrayList<>();

        pd = new ProgressDialog(this);
        pd.setTitle("Loading!");
        pd.setMessage("Please wait...");
        pd.setCanceledOnTouchOutside(false);

        //== logout button listner
        findViewById(R.id.logout_navigation_button1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //==checking internet connectivity==
                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {


                } else {

                    internet.setVisibility(View.GONE);
                    noInternet.setVisibility(View.VISIBLE);
                    //Toast.makeText(getApplicationContext(),"No internet connection...\nPlease connect to internet",Toast.LENGTH_LONG).show();
                    return;

                }

                //== clearing all the notificatins of older account ==
//                for(int i=0; i <mShared.getInt("notiCount"+ mShared.getString("industryid","") + mShared.getString("industryid",null),0); i++) {
//                    mShared.edit().remove("Noti"+ mShared.getString("industryid","")+String.valueOf(i+1)+mShared.getString("industryid",null)).apply();
//                }
//                mShared.edit().remove("notiCount"+ mShared.getString("industryid","")+mShared.getString("industryid",null)).apply();


                mShared.edit().putString("username","").apply();
                mShared.edit().putString("password","").apply();

                mShared.edit().putBoolean("flag",false).apply();
                startActivity(new Intent(levelActivity.this, LoginActivity.class));
                finish();
            }
        });

        //== innitializing item selected listner for the unit spinner ==
        unitSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try{
                    Log.d("control","first here");
                    fnRefreshContent();
                }catch (Exception e){
                    e.printStackTrace();
                    Log.d("control","second here");
                    //fngetunitsList();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.getMenu().getItem(1).setChecked(true);



        //== setting user name to the navigation drawer ==
        TextView tvUser = navigationView.getHeaderView(0).findViewById(R.id.nav_tv_username);
        tvUser.setText(mShared.getString("username","User name"));

        //=============chart===================



        mChart = findViewById(R.id.cubicChart);
        Log.d("calling","units api first");
        fngetunitsList(true);

        /*try{
            Log.d("control","thrid here");
            fnRefreshContent();
        }catch (Exception e){
            Log.d("control","four here");
            fngetunitsList();
        }*/

        //== initializing swipe refresh layout ==
        srl = findViewById(R.id.srl_level);
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                try{
                    fnRefreshContent();
                }catch (Exception e){
                    //fngetunitsList();
                }
                srl.setRefreshing(false);
            }
        });

    }


    //== this user defined function is to get the list of units in the respected industry and it will add all the elements into the spinner==

    public void fngetunitsList(final Boolean flag){

        pd.show();
        //== api call ==
        String BASE_URL = "http://54.71.150.252/aquagen/v1/industries/";
        String url = BASE_URL + mShared.getString("industryid",null) + "/units?category=Storage";
        url = url.replaceAll(" ","%20");

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.i("res", response);

                        //== logic after getting the api response ==
                        //== here units list gets updated only if tr is no units in the spinner ==
                        //== mMap is user to create a map of one units data==
                        //== usermap is a map of maps like 2d array which stores the data off all the units ==
                        //== the time getting from the api iis convertde into 12 hour format using manual logic and removing GMT tag at the end and storing ==

                        try {
                            JSONArray units = new JSONObject(response).getJSONArray("data");
                            //== since we are adding elements into the spinner again, we need to remove all older elements ==
                            if(flag == true) unitsList.clear();
                            for(int i=0;i<units.length();i++){
                                if( units.getJSONObject(i).getString("height").contains("null") || units.getJSONObject(i).getString("max_capacity").contains("null")) continue;
                                if(flag == true)

                                    unitsList.add(units.getJSONObject(i).getString("unit_name"));
                                Log.i("unit namee",units.getJSONObject(i).getString("unit_name"));
                                HashMap<String, String> mMap = new HashMap<>();
                                mMap.put("unit_id", units.getJSONObject(i).getString("unit_id"));
                                mMap.put("flow_factor", units.getJSONObject(i).getString("flow_factor"));
                                mMap.put("height", units.getJSONObject(i).getString("height"));
                                mMap.put("max_capacity", units.getJSONObject(i).getString("max_capacity"));
                                /*try {
                                    mMap.put("process_consumption", units.getJSONObject(i).getString("process_consumption"));
                                    mMap.put("unit_id", units.getJSONObject(i).getString("unit_id"));
                                    mMap.put("flow_factor", units.getJSONObject(i).getString("flow_factor"));
                                    mMap.put("height", units.getJSONObject(i).getString("height"));
                                    mMap.put("max_capacity", units.getJSONObject(i).getString("max_capacity"));
                                }catch(Exception e){
                                    e.printStackTrace();

                                }*/

//                                String time=units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("created_on");
//                                time = time.replace("GMT","");
//                                int val = Integer.parseInt(time.substring(time.indexOf(":")-2,time.indexOf(":")));
//                                if( val > 11 ) val = val - 12;
//                                time = time.substring(0, time.indexOf(":")-2) + String.valueOf(val) + time.substring(time.indexOf(":"));
//
//                                mMap.put("updated_time", time );

                                unitMap.put(units.getJSONObject(i).getString("unit_name"), mMap);

                                //== only when all the units get loaded we are updating the ui and spinner ==
                                //== we are not supposed to write outside the for loop because of multi threading==
                                if(i == units.length()-1 && flag == true)
                                {
                                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(levelActivity.this, android.R.layout.simple_spinner_dropdown_item, unitsList);
                                    unitSpinner.setAdapter(arrayAdapter);
                                    pd.show();
                                }
                                /*try{
                                    Log.i("inside try","units api");
                                    fnRefreshContent();
                                }catch (Exception e){
                                    Log.i("inside catch","units api");
                                    fngetunitsList(true);
                                }*/
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        pd.dismiss();
                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                pd.dismiss();
//                Log.i("error message  gs",error.getMessage());
                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {
                    //Toast.makeText(getApplicationContext(), "Sorry, no response from the server\nTry again after some time...", Toast.LENGTH_LONG).show();
                } else {

                    internet.setVisibility(View.GONE);
                    noInternet.setVisibility(View.VISIBLE);
                    //Toast.makeText(getApplicationContext(),"No internet connection...\nPlease connect to internet",Toast.LENGTH_LONG).show();
                    return;

                }
            }

        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };
        stringRequest_total.setShouldCache(true);

        RequestQueue requestQueue_total = Volley.newRequestQueue(getApplicationContext());
        requestQueue_total.add(stringRequest_total);

    }


    //== this function will refresh all the ui elements by getting the data from the api ==
    public void fnRefreshContent(){
        pd.show();
        //== api call ==
        String BASE_URL = "http://54.71.150.252/aquagen/v1/industries/";
        String url = BASE_URL + mShared.getString("industryid",null) + "/consumption/latest?category=Storage&unit_id="+unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id");
        url = url.replaceAll(" ","%20");

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        //== here we are storing all the values offline for the future use in maps ==
                        //== we are creating the temporary map (mMap) which holds all the details of particular unit in the industry ==
                        //== we have one more global map (unitMap ) which is the set of maps of the map like 2D array ==
                        //== which stores the details of all the units in that industry ==
                        //== time is for getting last updated time from the api ==
                        Log.i("latest_level_data", "Response is:" + response);
                        pd.dismiss();
                        try {
                            JSONArray units = new JSONObject(response).getJSONObject("data").getJSONArray("units");
                            if(units.length() == 0){
                                tvTotal.setText("");
                                fnSetEmptyTank(response);
                                fnGetLastUpdatedTime();
                            }
                            else{
                                Log.i("inside latest","inside else");
                                //unitsList.clear();
                                for(int i=0;i<units.length();i++){
                                    //unitsList.add(units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("unit_name"));
                                    Log.d("added_units","inside latest");
                                    HashMap<String, String> mMap = new HashMap<>();
                                    mMap.put("consumption", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("unit_name"));
                                    mMap.put("process_consumption", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("process_consumption"));
                                    mMap.put("flow_factor", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("flow_factor"));
                                    mMap.put("height", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("height"));
                                    mMap.put("max_capacity", units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("max_capacity"));

                                    mMap.put("unit_id", units.getJSONObject(i).keys().next());
                                    String time=units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("created_on");
                                    time = time.replace("GMT","");
                                    int val = Integer.parseInt(time.substring(time.indexOf(":")-2,time.indexOf(":")));
                                    int temp = val;
                                    if( val > 11 && val != 12 ){
                                        val = val - 12;
                                        time = time.substring(0, time.indexOf(":")-2) + String.valueOf(val) + time.substring(time.indexOf(":"));
                                    }
                                    if( val == 12){
                                        time = time.substring(0, time.indexOf(":")-2) + String.valueOf(val) + time.substring(time.indexOf(":"));
                                    }

                                    if( temp<12 ) time += " AM";
                                    else    time += "PM";

                                    mMap.put("updated_time", time );
                                    unitMap.put(units.getJSONObject(i).getJSONObject(units.getJSONObject(i).keys().next()).getString("unit_name"), mMap);

                                    if(i == units.length()-1)
                                    {
                                        tvRefreshTime.setText("Updated on " + unitMap.get(unitSpinner.getSelectedItem().toString()).get("updated_time"));
                                    }
                                }

                                fnSetData(response);
                            }

                            //fnSetData(response);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                pd.dismiss();
//                Log.i("error message  gs",error.getMessage());
                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {
                    Toast.makeText(getApplicationContext(), "Sorry, no response from the server\nTry again after some time...", Toast.LENGTH_LONG).show();
                } else {

                    internet.setVisibility(View.GONE);
                    noInternet.setVisibility(View.VISIBLE);
                    //Toast.makeText(getApplicationContext(),"No internet connection...\nPlease connect to internet",Toast.LENGTH_LONG).show();
                    return;

                }
            }

        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };
        stringRequest_total.setShouldCache(true);

        RequestQueue requestQueue_total = Volley.newRequestQueue(getApplicationContext());
        requestQueue_total.add(stringRequest_total);

    }

    private void fnSetEmptyTank(String response) {

        Log.i("inside empty", response);

        //== to store values ==
        ArrayList<Entry> entries = new ArrayList<>();
        //== to store x axis labels ==
        ArrayList<String> labels = new ArrayList<>();

        try {
            LineDataSet bardataset = new LineDataSet(entries, "feets");
            LineData data = new LineData(labels, bardataset);

            bardataset.setDrawCubic(true);
            bardataset.setDrawValues(false);

            //=======mChart parameters===============
            mChart.getAxisLeft().getLimitLines().clear();
            LimitLine limitLine = new LimitLine(Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height"))*0.85f);
//        Log.i("value", String.valueOf(val));
//        Log.i("actual value", String.valueOf(mShared.getFloat("max_level"+unitSpinner.getSelectedItem().toString(),12f)*0.9));
           // if (val < Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height")) * 0.85)
            limitLine.setLineColor(Color.BLACK);
            limitLine.setLabel("Threshold");
            limitLine.setLineWidth(3f);
            limitLine.setLabelPosition(LimitLine.LimitLabelPosition.LEFT_TOP);
            limitLine.enableDashedLine(30f, 10f, 0);
            limitLine.setTextSize(13f);
            limitLine.setTextColor(Color.RED);

            mChart.getAxisLeft().setAxisMaxValue(Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height")));
            mChart.getAxisRight().setAxisMaxValue(Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height")));
            mChart.getAxisLeft().setAxisMinValue(0f);
            mChart.getAxisRight().setAxisMinValue(0f);
            mChart.getAxisLeft().addLimitLine(limitLine);
            mChart.getAxisRight().setDrawLabels(false);
            mChart.setData(data);
            mChart.getXAxis().setDrawGridLines(false);
            mChart.getAxisLeft().setDrawGridLines(false);
            mChart.setScaleEnabled(false);
            mChart.setDescription("");  // set the description
            mChart.setTouchEnabled(false);
            mChart.animateY(1000);
            mChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
            mChart.getXAxis().setTextSize(9f);
            mChart.getXAxis().setDrawLabels(false);

            bardataset.setDrawCircles(false);
            bardataset.setLineWidth(1.8f);
            bardataset.setDrawFilled(true);
            bardataset.setFillColor(Color.argb(255, 64, 190, 237));
            bardataset.setFillAlpha(100);

            // =========== setting legend position============
            Legend l = mChart.getLegend();
            l.setPosition(Legend.LegendPosition.LEFT_OF_CHART);
            //l.setForm(Legend.LegendForm.LINE);
            l.setEnabled(false);
        }catch(Exception e){
            e.printStackTrace();

        }
    }

    private void fnGetLastUpdatedTime() {

        //pd.show();
        //== api call ==
        String BASE_URL = "http://54.71.150.252/aquagen/v1/industries/";
        String url = BASE_URL + mShared.getString("industryid", null) + "/consumption/lastupdated?unit_id=" + unitMap.get(unitSpinner.getSelectedItem().toString()).get("unit_id");
        url = url.replaceAll(" ", "%20");

        StringRequest stringRequest_total = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.i("last_updated", "Response is:" + response);
                        pd.dismiss();
                        try {
                            JSONArray data = new JSONObject(response).getJSONArray("data");
                            //unitsList.clear();
                            for (int i = 0; i < data.length(); i++) {

                                Log.i("inside lastupdated","unit id");

                                HashMap<String, String> mMap = new HashMap<>();
                                mMap.put("unit_id", data.getJSONObject(i).keys().next());
                                mMap.put("unit_name",data.getJSONObject(i).getJSONObject(data.getJSONObject(i).keys().next()).getString("unit_name"));

                                String time = data.getJSONObject(i).getJSONObject(data.getJSONObject(i).keys().next()).getString("last_updated_on");
                                time = time.replace("GMT", "");
                                int val = Integer.parseInt(time.substring(time.indexOf(":") - 2, time.indexOf(":")));
                                int temp = val;
                                if (val > 11 && val != 12){
                                    val = val - 12;
                                    time = time.substring(0, time.indexOf(":") - 2) + String.valueOf(val) + time.substring(time.indexOf(":"));
                                }

                                else if( val == 12){
                                    time = time.substring(0, time.indexOf(":") - 2) + String.valueOf(val) + time.substring(time.indexOf(":"));

                                }

                                if (temp < 12) time += " AM";
                                else time += "PM";

                                mMap.put("last_updated_on", time);
                                unitMap.put(data.getJSONObject(i).getJSONObject(data.getJSONObject(i).keys().next()).getString("unit_name"), mMap);

                                if (i == data.length()-1) {
                                    //Log.i("display last_updated", unitMap.get(unitSpinner.getSelectedItem().toString()).get("last_updated_on"));
                                    tvRefreshTime.setText("Last Updated On " + unitMap.get(unitSpinner.getSelectedItem().toString()).get("last_updated_on"));
                                }
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                //pd.dismiss();
                handleError(error);

            }

        }) {
            @Override
            public Map<String, String> getHeaders() {

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", mShared.getString("token", "invalid token.."));
                return headers;
            }
        };
        stringRequest_total.setShouldCache(true);

        RequestQueue requestQueue_total = Volley.newRequestQueue(getApplicationContext());
        requestQueue_total.add(stringRequest_total);
    }


    private void handleError(VolleyError error) {


        if(error instanceof NoConnectionError){
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = null;
            if (cm != null) {
                activeNetwork = cm.getActiveNetworkInfo();
            }
            if(activeNetwork != null && activeNetwork.isConnectedOrConnecting()){
                /*Toast.makeText(MainActivity.this
                        , "Server is not connected to internet.",
                        Toast.LENGTH_SHORT).show();*/
            } else {

                internet.setVisibility(View.GONE);
                noInternet.setVisibility(View.VISIBLE);
                tvRefreshTime.setVisibility(View.GONE);

                Toast.makeText(levelActivity.this
                        , "Your device is not connected to internet.",
                        Toast.LENGTH_SHORT).show();
            }
        }
        else if (error instanceof NetworkError)
        {
            // this log statement is giving exception because of when the status is success , error will be null but we are manually printing so it throws exception.
            //Log.i("printing n/w error", String.valueOf(error.networkResponse.statusCode));
            Toast.makeText(levelActivity.this
                    , " Network connection lost. Please check your connectivity.",
                    Toast.LENGTH_SHORT).show();
        }
       /* else if (error instanceof NetworkError || error.getCause() instanceof ConnectException
                || (error.getCause().getMessage() != null
                && error.getCause().getMessage().contains("connection")))
        {
            Toast.makeText(MainActivity.this
                    , " Network connection lost. Please check your connectivity.",
                    Toast.LENGTH_SHORT).show();
        }*/
        else if (error.getCause() instanceof MalformedURLException)
        {
            Toast.makeText(levelActivity.this
                    , "Bad Request.", Toast.LENGTH_SHORT).show();
        }
        else if (error instanceof ParseError || error.getCause() instanceof IllegalStateException
                || error.getCause() instanceof JSONException
                || error.getCause() instanceof XmlPullParserException)
        {
            Toast.makeText(levelActivity.this
                    , "Parse Error (because of invalid json or xml).",
                    Toast.LENGTH_SHORT).show();
        }
        else if (error.getCause() instanceof OutOfMemoryError)
        {
            Toast.makeText(levelActivity.this
                    , "Your device is out of Memory.", Toast.LENGTH_SHORT).show();
        }
        else if (error instanceof AuthFailureError)
        {
            Toast.makeText(levelActivity.this
                    , "Server couldn't find the authenticated request.",
                    Toast.LENGTH_SHORT).show();
        }
        else if (error instanceof ServerError || error.getCause() instanceof ServerError)
        {
            Toast.makeText(levelActivity.this
                    , "Server is not responding.Please Contact Administrator.", Toast.LENGTH_SHORT).show();
        }
        else if (error instanceof TimeoutError || error.getCause() instanceof SocketTimeoutException
                || error.getCause() instanceof ConnectTimeoutException
                || error.getCause() instanceof SocketException
                )
        {
            Toast.makeText(levelActivity.this
                    , "Very slow internet connection.",
                    Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(levelActivity.this
                    , "An unknown error occurred.",
                    Toast.LENGTH_SHORT).show();
        }

    }


    //== this function is to process the data and update it into the graph ==
    private void fnSetData(String response){

        Log.i("inside fnSet","from latest");

        //== to store values ==
        ArrayList<Entry> entries=new ArrayList<>();
        //== to store x axis labels ==
        ArrayList<String> labels =new ArrayList<>();

        float val=0f;
        for(int i=1 ;i<5; i++)
        {

            //== this value is used for getting curved shape (water level ) ==
            //== just logical thing ==
            //== we are plotting 5 values with plus some constant and minus some constant with the actual value to get the curved thing at the top ==
            int pow=100;
            try {

                if(i==1){
                    JSONObject obj = new JSONObject(response);

                    val = Float.parseFloat(obj.getJSONObject("data").getJSONArray("units").getJSONObject(0).getJSONObject(obj.getJSONObject("data").getJSONArray("units").getJSONObject(0).keys().next()).getString("level"));
                    val /= 30.48;
                    val = Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height"))-val;
                    if( val < 0 )  val = Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height"));

                    float text_val = val / Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height")) * Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("max_capacity"));

                    String temp = String.valueOf((int) (text_val / 1000)) + " K \n liters";
                    tvTotal.setText(temp);
                    labels.add(String.valueOf(i));


                    /*val = val / Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height")) * Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("max_capacity"));

                    String temp = String.valueOf((int)(val / 1000))+" K \n liters";
                    tvTotal.setText(temp);
                    labels.add(String.valueOf(i));*/


//                    pow = (int) Math.pow(10, String.valueOf((int)val).length()+1);
                    if( i%2 == 0)  entries.add(new Entry(val - val/pow, i-1));
                    else entries.add(new Entry(val + val/pow, i-1));

                }
                else {
                    labels.add(String.valueOf(i));
                    if (i % 2 == 0) entries.add(new Entry(val - val / pow, i - 1));
                    else entries.add(new Entry(val + val / pow, i - 1));
                }
            }catch(Exception e) {
                Log.i("gs error", e.getMessage());
            }
        }

        try {
            LineDataSet bardataset = new LineDataSet(entries, "feets");
            LineData data = new LineData(labels, bardataset);

            bardataset.setDrawCubic(true);
            bardataset.setDrawValues(false);

            //=======mChart parameters===============
            mChart.getAxisLeft().getLimitLines().clear();
            LimitLine limitLine = new LimitLine(Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height"))*0.85f);
//        Log.i("value", String.valueOf(val));
//        Log.i("actual value", String.valueOf(mShared.getFloat("max_level"+unitSpinner.getSelectedItem().toString(),12f)*0.9));
            if (val < Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height")) * 0.85)
                limitLine.setLineColor(Color.BLACK);
            limitLine.setLabel("Threshold");
            limitLine.setLineWidth(3f);
            limitLine.setLabelPosition(LimitLine.LimitLabelPosition.LEFT_TOP);
            limitLine.enableDashedLine(30f, 10f, 0);
            limitLine.setTextSize(13f);
            limitLine.setTextColor(Color.RED);

            mChart.getAxisLeft().setAxisMaxValue(Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height")));
            mChart.getAxisRight().setAxisMaxValue(Float.parseFloat(unitMap.get(unitSpinner.getSelectedItem().toString()).get("height")));
            mChart.getAxisLeft().setAxisMinValue(0f);
            mChart.getAxisRight().setAxisMinValue(0f);
            mChart.getAxisLeft().addLimitLine(limitLine);
            mChart.getAxisRight().setDrawLabels(false);
            mChart.setData(data);
            mChart.getXAxis().setDrawGridLines(false);
            mChart.getAxisLeft().setDrawGridLines(false);
            mChart.setScaleEnabled(false);
            mChart.setDescription("");  // set the description
            mChart.setTouchEnabled(false);
            mChart.animateY(1000);
            mChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
            mChart.getXAxis().setTextSize(9f);
            mChart.getXAxis().setDrawLabels(false);

            bardataset.setDrawCircles(false);
            bardataset.setLineWidth(1.8f);
            bardataset.setDrawFilled(true);
            bardataset.setFillColor(Color.argb(255, 64, 190, 237));
            bardataset.setFillAlpha(100);

            // =========== setting legend position============
            Legend l = mChart.getLegend();
            l.setPosition(Legend.LegendPosition.LEFT_OF_CHART);
            //l.setForm(Legend.LegendForm.LINE);
            l.setEnabled(false);
        }catch(Exception e){

        }

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            startActivity(new Intent(levelActivity.this,MainActivity.class));
            super.onBackPressed();
        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if( id == R.id.nav_but_contactus)
        {
            View view2= View.inflate(getApplicationContext(), R.layout.contactus, null);
            final Dialog dia = new Dialog(this);
            dia.setContentView(view2);


            TextView tv = view2.findViewById(R.id.tvContactAddress);
            tv.setText(Html.fromHtml("<br><br><span style=\"font-size:140%\"><b>Address : </b></span> Fluxgen Engineering Technologies<br>#1064, 1st floor, 18th Main<br>2nd Stage,BTM Layout<br>Bangalore 560076"));


            view2.findViewById(R.id.btCall).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:08042033298"));
                    startActivity(intent);
                }
            });
            dia.setOnKeyListener(new DialogInterface.OnKeyListener() {
                @Override
                public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                    if(keyCode == KeyEvent.KEYCODE_BACK){
                        startActivity(new Intent(levelActivity.this,levelActivity.class));
                        finish();
                    }
                    return true;
                }
            });

            Button cancelButton = view2.findViewById(R.id.cancelButton);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dia.dismiss();

                }
            });

            dia.show();
            dia.setCancelable(true);

        }
        else if( id == R.id.nav_but_about){
            startActivity(new Intent( levelActivity.this , AboutUs.class));
        }
        else if( id == R.id.nav_but_home){
            startActivity(new Intent(levelActivity.this,MainActivity.class));
            finish();
            super.onBackPressed();

        }
        else if( id == R.id.nav_but_level){
            //navigationView.getMenu().getItem(id).setChecked(true);
        }

        else if( id == R.id.nav_but_noti){
            startActivity(new Intent(levelActivity.this, NotificationList.class));
            finish();
            //super.onBackPressed();
        }
        else if( id == R.id.nav_but_shift){
            startActivity(new Intent(levelActivity.this, ShiftActivity.class));
            finish();
        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //== this function will generate the token when the existing tokens gets invalid ==
    public void fnGenerateToken(){

        if(SplashScreenActivity.tokenValid) return;

        MainActivity.tokenThread.cancel();
        MainActivity.tokenThread.start();

        RequestQueue requestQueue = Volley.newRequestQueue(levelActivity.this);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Username", mShared.getString("username",""));
            jsonObject.put("password", mShared.getString("password",""));

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, JSON_URL, jsonObject, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    Log.i("response of loginAPI", String.valueOf(response));
                    JSONObject data = null;

                    try {

                        data = response.getJSONObject("data");
                        String ID = data.getString("industry_id");
                        String token = data.getString("token");
                        mShared.edit().putString("token", token).apply();
                        mShared.edit().putString("industryid", ID).apply();
                        String status = response.getString("status");
                        pd.dismiss();

                        SplashScreenActivity.tokenValid = true;

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //Log.i("error", "error ocuured");

                    pd.dismiss();
                    return;

                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
//                            headers.put("Content-Type", "application/json");
                    String credentials = mShared.getString("username","") + ":" + mShared.getString("password","");
                    //String credentials = String.format(username.getText().toString(),password.getText().toString());
                    Log.i("Display", credentials);
                    String auth = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                    Log.i("Display generated auth", auth);
                    //headers.put("Authorization", "Basic ZGFyc2hhbmFrYXZ5YUBnbWFpbC5jb206dGVzdDEyMzQ=");
                    headers.put("Authorization", auth);
                    return headers;
                }
            };
            requestQueue.add(jsonObjectRequest);
        } catch (JSONException e) {
            pd.dismiss();
            e.printStackTrace();
        }

    }


    @Override
    protected void onRestart() {
        super.onRestart();
        fnGenerateToken();
    }

    @Override
    protected void onPause() {
        super.onPause();
        fnGenerateToken();
    }

    @Override
    protected void onResume() {
        super.onResume();
        fnGenerateToken();
    }

}

