package com.example.admin.aquagen.Notifications;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.admin.aquagen.Authentication.LoginActivity;
import com.example.admin.aquagen.Home.MainActivity;
import com.example.admin.aquagen.Info.AboutUs;
import com.example.admin.aquagen.Level.levelActivity;
import com.example.admin.aquagen.MilkActivity;
import com.example.admin.aquagen.R;
import com.example.admin.aquagen.Shift.ShiftActivity;
import com.example.admin.aquagen.SplashScreenActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class NotificationList extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawer;
    private ProgressDialog pd;
    private  NavigationView navigationView;
    private SwipeRefreshLayout srl;
    private Switch switcher;
    private Toolbar toolbar;
    private SharedPreferences mShared;
    private String JSON_URL = "http://54.71.150.252/aquagen/v1/auth/login";

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_list);
         toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.getMenu().getItem(2).setChecked(true);

        //=============main code========================



        //== initializing the  shared preference, because when we directly open this activity from the notifications many variables which are in the SplashScreenActivity are not initialized ==
        mShared = this.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);

        //== setting the user name for the textView in the navigation drawer ==
        TextView tvUser = navigationView.getHeaderView(0).findViewById(R.id.nav_tv_username);
        tvUser.setText(mShared.getString("username", "User name"));


        //========notification switcher logic============

        switcher = (Switch) findViewById(R.id.switcher);

        if (mShared.getBoolean("notification_switcher",true)){
            switcher.setChecked(true);
        }
        else {
            switcher.setChecked(false);
        }



        //==============Setting progress dialog properties====================
        pd = new ProgressDialog(NotificationList.this);
        pd.setTitle("Loading!");
        pd.setMessage("Please wait...");
        pd.setCanceledOnTouchOutside(false);
        pd.setCancelable(false);


        //== setting action for clearAll notification button ==
        //== all the notifications which belongs to the currently logged in industry is removed ==
        toolbar.findViewById(R.id.tvClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0; i <mShared.getInt("notiCount"+ mShared.getString("industryid",""),0); i++) {
                    mShared.edit().remove("Noti"+ mShared.getString("industryid","")+String.valueOf(i+1)).apply();
                }
                mShared.edit().remove("notiCount"+ mShared.getString("industryid","")).apply();
//                fnsetData();
                LinearLayout ll = findViewById(R.id.notilinearlayout);
                ll.removeAllViews();
            }
        });


        switcher.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(switcher.isChecked()){
                    Toast.makeText(getApplication(),"Notifications Enabled",Toast.LENGTH_LONG).show();
                    mShared.edit().putBoolean("notification_switcher",true).apply();

                }
                else{
                    Toast.makeText(getApplication(),"Notifications Disabled",Toast.LENGTH_LONG).show();
                    mShared.edit().putBoolean("notification_switcher",false).apply();
                }

            }
        });

        //== setting action for the signout button ==
        findViewById(R.id.logout_navigation_button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //== checking the internet connectivity ==
                ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {


                } else {

                    Toast.makeText(getApplicationContext(),"No internet connection...\nPlease connect to internet",Toast.LENGTH_LONG).show();
                    return;

                }

                //== clearing all the notificatins of older account ==
//                for(int i=0; i <mShared.getInt("notiCount"+ mShared.getString("industryid",""),0); i++) {
//                    mShared.edit().remove("Noti"+ mShared.getString("industryid","")+String.valueOf(i+1)).apply();
//                }
//                mShared.edit().remove("notiCount"+ mShared.getString("industryid","")).apply();


                mShared.edit().putString("username","").apply();
                mShared.edit().putString("password","").apply();

                //==setting the boolean flag to notify user is signed out ==
                //== which will make the app to directly open LoginActivity  when ever user opens ==
                mShared.edit().putBoolean("flag",false).apply();
                startActivity(new Intent(NotificationList.this, LoginActivity.class));
                finish();
            }
        });

        Log.i("counts",String.valueOf(mShared.getInt("notiCount"+ mShared.getString("industryid",""),0)));

        //== since loading the notifications will struks the user interface we are doing it in background ==
        //== first we are building each notification and adding it to the layout dynamicallu one by one  ==
        loadNotificationAsyncTask myTask = new loadNotificationAsyncTask((LinearLayout) findViewById(R.id.notilinearlayout), NotificationList.this);
        myTask.execute();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            try{
                getIntent().getExtras().getBoolean("pop_up_notification_flag",false);
                startActivity(new Intent(NotificationList.this,MainActivity.class));
                super.onBackPressed();
            }catch(Exception e){
                startActivity(new Intent(NotificationList.this, MainActivity.class));
                finish();
            }

        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        if(!mShared.getBoolean("flag",false))
        {
            startActivity(new Intent(NotificationList.this, LoginActivity.class));
            finish();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if( id == R.id.nav_but_contactus)
        {
            View view2= View.inflate(getApplicationContext(), R.layout.contactus, null);
            final Dialog dia = new Dialog(this);
            dia.setContentView(view2);

            TextView tv = view2.findViewById(R.id.tvContactAddress);
            tv.setText(Html.fromHtml("<br><br><span style=\"font-size:140%\"><b>Address : </b></span> Fluxgen Engineering Technologies<br>#1064, 1st floor, 18th Main<br>2nd Stage,BTM Layout<br>Bangalore 560076"));

            view2.findViewById(R.id.btCall).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:08042033298"));
                    startActivity(intent);
                }
            });

            dia.setOnKeyListener(new DialogInterface.OnKeyListener() {
                @Override
                public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                    if(keyCode == KeyEvent.KEYCODE_BACK){
                        startActivity(new Intent(NotificationList.this,NotificationList.class));
                        finish();
                    }
                    return true;
                }
            });

            Button cancelButton = view2.findViewById(R.id.cancelButton);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dia.dismiss();

                }
            });

            dia.show();
            dia.setCancelable(true);

        }
        else if( id == R.id.nav_but_about){
            startActivity(new Intent( NotificationList.this , AboutUs.class));
        }
        else if( id == R.id.nav_but_home){
            startActivity(new Intent(NotificationList.this, MainActivity.class));
            finish();
            super.onBackPressed();

        }
        else if( id == R.id.nav_but_level){
            startActivity(new Intent(NotificationList.this, levelActivity.class));
            finish();
        }
        else if( id == R.id.nav_but_noti){
            //navigationView.getMenu().getItem(id).setChecked(true);
            /*startActivity(new Intent(NotificationList.this, NotificationList.class));
            finish();*/
        }



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //== this function will generate the token when the existing tokens gets invalid ==
    public void fnGenerateToken(){

        if(SplashScreenActivity.tokenValid) return;

        if(MainActivity.tokenThread == null)
        {
            MainActivity.tokenThread = new CountDownTimer(50000, 25000) {

                @Override
                public void onTick(long millisUntilFinished) {

                }

                @Override
                public void onFinish() {
                    //== flag to control the generation of new token even if its not required ==
                    //== like even if the user enters the other activity it will not generate new tooken untill the olderone gets invalis ==
                    SplashScreenActivity.tokenValid = false;
                    //== function to generate the new token (modified version of the login activity) ==
                    fnGenerateToken();
                }
            };
        }

        MainActivity.tokenThread.cancel();
        MainActivity.tokenThread.start();

        RequestQueue requestQueue = Volley.newRequestQueue(NotificationList.this);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Username", mShared.getString("username",""));
            jsonObject.put("password", mShared.getString("password",""));

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, JSON_URL, jsonObject, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    Log.i("response of loginAPI", String.valueOf(response));
                    JSONObject data = null;

                    try {

                        data = response.getJSONObject("data");
                        String ID = data.getString("industry_id");
                        String token = data.getString("token");
                        mShared.edit().putString("token", token).apply();
                        mShared.edit().putString("industryid", ID).apply();
                        String status = response.getString("status");
                        pd.dismiss();
                        SplashScreenActivity.tokenValid = true;

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //Log.i("error", "error ocuured");

                    pd.dismiss();
                    return;

                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
//                            headers.put("Content-Type", "application/json");
                    String credentials = mShared.getString("username","") + ":" + mShared.getString("password","");
                    //String credentials = String.format(username.getText().toString(),password.getText().toString());
                    Log.i("Display", credentials);
                    String auth = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                    Log.i("Display generated auth", auth);
                    //headers.put("Authorization", "Basic ZGFyc2hhbmFrYXZ5YUBnbWFpbC5jb206dGVzdDEyMzQ=");
                    headers.put("Authorization", auth);
                    return headers;
                }
            };
            requestQueue.add(jsonObjectRequest);
        } catch (JSONException e) {
            pd.dismiss();
            e.printStackTrace();
        }

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        fnGenerateToken();
    }

    @Override
    protected void onPause() {
        super.onPause();
        fnGenerateToken();
    }

    @Override
    protected void onResume() {
        super.onResume();
        fnGenerateToken();

        //  To Clear all notifications, once user opened notification Page.
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancelAll();
    }

}
