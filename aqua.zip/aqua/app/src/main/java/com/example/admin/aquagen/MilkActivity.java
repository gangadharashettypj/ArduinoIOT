package com.example.admin.aquagen;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.admin.aquagen.Home.MainActivity;
import com.example.admin.aquagen.Info.AboutUs;
import com.example.admin.aquagen.Level.levelActivity;
import com.example.admin.aquagen.Notifications.NotificationList;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.listener.ColumnChartOnValueSelectListener;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.Column;
import lecho.lib.hellocharts.model.ColumnChartData;
import lecho.lib.hellocharts.model.SubcolumnValue;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.ColumnChartView;

public class MilkActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    private ColumnChartData data;
    private ColumnChartView chart;
    private NavigationView navigationView;
    private ProgressDialog pd;
    private SharedPreferences mShared;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_milk);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //======main code========
        mShared = this.getSharedPreferences("com.example.admin.aquagen", Context.MODE_PRIVATE);
        chart =findViewById(R.id.lineMilkChart);
        chart.setOnValueTouchListener(new ValueTouchListener());
        chart.setZoomEnabled(false);

        //==============Setting progress dialog properties====================
        pd = new ProgressDialog(MilkActivity.this);
        pd.setTitle("Loading!");
        pd.setMessage("Please wait...");
        pd.setCanceledOnTouchOutside(false);
        pd.setCancelable(false);

        generateData();


    }
    private static final int DEFAULT_DATA = 0;

    private boolean hasAxes = true;
    private boolean hasAxesNames = true;
    private int dataType = DEFAULT_DATA;

    private class ValueTouchListener implements ColumnChartOnValueSelectListener {

        @Override
        public void onValueSelected(int columnIndex, int subcolumnIndex, SubcolumnValue value) {
//            Toast.makeText(MilkActivity.this, "Selected: " + value, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onValueDeselected() {
            // TODO Auto-generated method stub

        }

    }

    private List<Float> list;
    private List<String> list1;
    private void generateDefaultData() {
        list = new ArrayList<>();
        list1 = new ArrayList<>();
        int numSubcolumns = 2;
        int numColumns = 6;
        // Column can have many subcolumns, here by default I use 1 subcolumn in each of 8 columns.
        List<Column> columns = new ArrayList<Column>();
        List<SubcolumnValue> values;
        for (int i = 0; i < numColumns; ++i) {

            values = new ArrayList<SubcolumnValue>();
            for (int j = 0; j < numSubcolumns; ++j) {
                float flo = (float) Math.random() * 50 + 5;
                if (j==0)
                    values.add(new SubcolumnValue(flo, Color.argb(255, 45, 95, 117)).setLabel(String.valueOf(flo)));
                else
                    values.add(new SubcolumnValue(flo, ChartUtils.COLOR_ORANGE).setLabel(String.valueOf(flo)));

            }
            list.add(Float.parseFloat(String.valueOf((float)i)));
            list1.add(String.valueOf(i));
            Column column = new Column(values);
//            column.setHasLabels(true);
            column.setHasLabelsOnlyForSelected(true);

            columns.add(column);
        }


        data = new ColumnChartData(columns);
        data.setValueLabelBackgroundEnabled(false);
        data.setValueLabelsTextColor(Color.BLACK);
        data.setValueLabelTextSize(9);
        if (hasAxes) {
            Axis axisX = Axis.generateAxisFromCollection(list,list1);
            Axis axisY = new Axis().setHasLines(true);
            if (hasAxesNames) {
                axisX.setName(MainActivity.tvDuration.getText().toString()+" water and milk consumtion in kilo liters");
                axisY.setName("Axis Y");
            }
            data.setAxisXBottom(axisX);
//            data.setAxisYLeft(axisY);
        } else {
            data.setAxisXBottom(null);
            data.setAxisYLeft(null);
        }

        chart.setColumnChartData(data);
        Viewport v = new Viewport(chart.getMaximumViewport());
        //do something with viewport
        v.top = v.top + 5;
        //set current viewport, has to by within max viewport area

        chart.setCurrentViewport(v);
        chart.setMaximumViewport(v);
        chart.animate();


    }

    private void generateData() {
        switch (dataType) {
            case DEFAULT_DATA:
                generateDefaultData();
                break;
//            case SUBCOLUMNS_DATA:
//                generateSubcolumnsData();
//                break;
//            case STACKED_DATA:
//                generateStackedData();
//                break;
//            case NEGATIVE_SUBCOLUMNS_DATA:
//                generateNegativeSubcolumnsData();
//                break;
//            case NEGATIVE_STACKED_DATA:
//                generateNegativeStackedData();
//                break;
//            default:
//                generateDefaultData();
//                break;
        }
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if( id == R.id.nav_but_contactus)
        {
            View view2= View.inflate(getApplicationContext(), R.layout.contactus, null);
            Dialog dia = new Dialog(this);
            dia.setContentView(view2);

            TextView tv = view2.findViewById(R.id.tvContactAddress);
            tv.setText(Html.fromHtml("<br><br><span style=\"font-size:140%\"><b>Address : </b></span> Fluxgen Engineering Technologies<br>#1064, 1st floor, 18th Main<br>2nd Stage,BTM Layout<br>Bangalore 560076"));

            view2.findViewById(R.id.btCall).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:8042033298"));
                    startActivity(intent);
                }
            });

            dia.show();
            dia.setCanceledOnTouchOutside(false);

        }
        else if( id == R.id.nav_but_about){
            startActivity(new Intent( MilkActivity.this , AboutUs.class));
        }
        else if( id == R.id.nav_but_home){

            super.onBackPressed();
        }
        else if( id == R.id.nav_but_level){
            startActivity(new Intent(MilkActivity.this, levelActivity.class));
            finish();
        }
        else if( id == R.id.nav_but_noti){
            startActivity(new Intent(MilkActivity.this, NotificationList.class));
            finish();
        }
        else if( id == R.id.nav_but_milk){
            startActivity(new Intent(MilkActivity.this, MilkActivity.class));
            finish();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
